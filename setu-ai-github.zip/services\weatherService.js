/**
 * Real-Time Weather, Observed vs. Forecast Rainfall, and Air Quality (AQI) Service.
 * Uses Open-Meteo Weather + Open-Meteo Air Quality (keyless real-time APIs)
 * and optional OpenWeatherMap when WEATHER_API_KEY is configured.
 * Never fabricates weather, rainfall, or AQI data.
 */

const WMO_DESCRIPTIONS = {
  0: { en: 'Clear sky', hi: 'साफ आसमान' },
  1: { en: 'Mainly clear', hi: 'मुख्यतः साफ' },
  2: { en: 'Partly cloudy', hi: 'आंशिक बादल' },
  3: { en: 'Overcast', hi: 'घने बादल' },
  45: { en: 'Fog', hi: 'कोहरा' },
  48: { en: 'Depositing rime fog', hi: 'घना कोहरा' },
  51: { en: 'Light drizzle', hi: 'हल्की बूंदाबांदी' },
  53: { en: 'Moderate drizzle', hi: 'मध्यम बूंदाबांदी' },
  55: { en: 'Dense drizzle', hi: 'तेज़ बूंदाबांदी' },
  61: { en: 'Slight rain', hi: 'हल्की बारिश' },
  63: { en: 'Moderate rain', hi: 'मध्यम बारिश' },
  65: { en: 'Heavy rain', hi: 'भारी बारिश' },
  80: { en: 'Slight rain showers', hi: 'हल्की बौछारें' },
  81: { en: 'Moderate rain showers', hi: 'मध्यम बौछारें' },
  82: { en: 'Violent rain showers', hi: 'तेज़ बौछारें' },
  95: { en: 'Thunderstorm', hi: 'आंधी-तूफान' },
  96: { en: 'Thunderstorm with hail', hi: 'ओलावृष्टि के साथ तूफान' },
  99: { en: 'Severe thunderstorm', hi: 'गंभीर तूफान' }
};

export async function fetchRealWeather(lat, lon) {
  const latitude = Number(lat);
  const longitude = Number(lon);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    throw new Error('Valid latitude and longitude coordinates are required.');
  }

  const omUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&past_days=2&forecast_days=5&current=temperature_2m,relative_humidity_2m,wind_speed_10m,precipitation,rain,weather_code&hourly=precipitation,precipitation_probability,temperature_2m,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,weather_code&timezone=auto`;

  const resp = await fetch(omUrl, { signal: AbortSignal.timeout(12000) });
  if (!resp.ok) {
    throw new Error(`Open-Meteo weather API returned HTTP ${resp.status}.`);
  }
  const data = await resp.json();
  const cur = data.current || {};
  const nowIso = cur.time || new Date().toISOString();
  const todayStr = nowIso.slice(0, 10);

  // Separate observed hourly rain (<= current observation timestamp) from forecast
  const hTimes = data.hourly?.time || [];
  const hPrecip = data.hourly?.precipitation || [];
  const hProb = data.hourly?.precipitation_probability || [];
  const nowMs = Date.parse(nowIso) || Date.now();

  let todayObservedRainMm = 0;
  let last24hObservedRainMm = 0;
  let next24hForecastRainMm = 0;
  const hourlySeries = [];

  for (let i = 0; i < hTimes.length; i++) {
    const tStr = hTimes[i];
    const tMs = Date.parse(tStr);
    const mm = Number(hPrecip[i] || 0);
    const prob = Number(hProb[i] || 0);
    const isObserved = Number.isFinite(tMs) ? tMs <= nowMs : tStr <= nowIso;

    if (isObserved && tStr.startsWith(todayStr)) {
      todayObservedRainMm += mm;
    }
    if (isObserved && Number.isFinite(tMs) && nowMs - tMs <= 24 * 3600 * 1000 && nowMs >= tMs) {
      last24hObservedRainMm += mm;
    }
    if (!isObserved && Number.isFinite(tMs) && tMs - nowMs <= 24 * 3600 * 1000) {
      next24hForecastRainMm += mm;
    }

    hourlySeries.push({
      time: tStr,
      precipMm: Number(mm.toFixed(2)),
      precipProb: prob,
      isObserved
    });
  }

  // Next 4h forecast rain probability
  const upcomingHours = hourlySeries.filter(h => !h.isObserved).slice(0, 4);
  const rainProbNext4h = upcomingHours.length ? Math.max(...upcomingHours.map(h => h.precipProb)) : 0;

  const dDates = data.daily?.time || [];
  const daily = dDates.map((date, idx) => {
    const code = data.daily?.weather_code?.[idx];
    const desc = WMO_DESCRIPTIONS[code] || { en: 'Forecast', hi: 'पूर्वानुमान' };
    return {
      date,
      isPast: date < todayStr,
      isToday: date === todayStr,
      minC: data.daily?.temperature_2m_min?.[idx] ?? null,
      maxC: data.daily?.temperature_2m_max?.[idx] ?? null,
      rainMm: Number((data.daily?.precipitation_sum?.[idx] ?? 0).toFixed(1)),
      maxRainProb: data.daily?.precipitation_probability_max?.[idx] ?? 0,
      maxWindKmh: data.daily?.wind_speed_10m_max?.[idx] ?? null,
      condition: desc.en,
      conditionHi: desc.hi,
      weatherCode: code
    };
  });

  const yesterdayDay = daily.filter(d => d.isPast).slice(-1)[0] || null;
  const tomorrowDay = daily.find(d => d.date > todayStr) || null;
  const curDesc = WMO_DESCRIPTIONS[cur.weather_code] || { en: 'Live observation', hi: 'ताज़ा मौसम' };

  const tempC = cur.temperature_2m;
  const windKmh = cur.wind_speed_10m;
  const humidity = cur.relative_humidity_2m;
  const currentPrecipMm = cur.precipitation ?? 0;

  const warnings = [];
  if (windKmh > 25) warnings.push('Strong wind (>25 km/h): high spray drift and crop lodging risk.');
  else if (windKmh > 15) warnings.push('Wind >15 km/h: avoid foliar spraying.');
  if (rainProbNext4h >= 50 || currentPrecipMm > 0.5) warnings.push('Rain active or expected soon: delay irrigation and spraying.');
  if (tempC >= 38) warnings.push('Heat stress alert (≥38°C): avoid midday outdoor work & irrigate early morning/evening.');
  if (tempC <= 4) warnings.push('Cold / frost risk (≤4°C): protect sensitive winter crops.');

  let sprayStatus = 'OPTIMAL';
  let sprayHeadline = 'Conditions Favorable for Morning/Evening Spraying';
  let sprayHeadlineHi = 'सुबह/शाम छिड़काव के लिए मौसम अनुकूल है';
  if (currentPrecipMm > 0 || rainProbNext4h >= 40) {
    sprayStatus = 'NO_SPRAY';
    sprayHeadline = 'Do Not Spray — Rain / Washoff Risk';
    sprayHeadlineHi = 'अभी छिड़काव न करें — बारिश की संभावना है';
  } else if (windKmh > 15) {
    sprayStatus = 'NO_SPRAY';
    sprayHeadline = 'Do Not Spray — High Wind Drift Risk';
    sprayHeadlineHi = 'अभी छिड़काव न करें — तेज हवा चल रही है';
  } else if (temperatureCheck(tempC)) {
    sprayStatus = 'CAUTION';
    sprayHeadline = 'Caution — Avoid Midday Heat (>35°C)';
    sprayHeadlineHi = 'सावधानी — दोपहर की तेज धूप (>35°C) में छिड़काव न करें';
  }

  // Optional OpenWeatherMap enrichment if WEATHER_API_KEY is configured
  let provider = 'Open-Meteo Live Meteorological API';
  const owmKey = (process.env.WEATHER_API_KEY || '').trim();
  if (owmKey) {
    try {
      const owmResp = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=metric&appid=${encodeURIComponent(owmKey)}`,
        { signal: AbortSignal.timeout(5000) }
      );
      if (owmResp.ok) provider = 'OpenWeatherMap + Open-Meteo';
    } catch {
      // keep Open-Meteo
    }
  }

  return {
    provider,
    coordinates: { lat: latitude, lon: longitude },
    timezone: data.timezone || 'auto',
    observationTime: nowIso,
    temperatureC: tempC,
    humidityPercent: humidity,
    windSpeedKmh: windKmh,
    currentPrecipMm,
    rainProbNext4h,
    condition: curDesc.en,
    conditionHi: curDesc.hi,
    weatherCode: cur.weather_code,
    rainfall: {
      todayObservedMm: Number(todayObservedRainMm.toFixed(1)),
      last24hObservedMm: Number(last24hObservedRainMm.toFixed(1)),
      yesterdayObservedMm: yesterdayDay ? yesterdayDay.rainMm : null,
      next24hForecastMm: Number(next24hForecastRainMm.toFixed(1)),
      tomorrowForecastMm: tomorrowDay ? tomorrowDay.rainMm : null,
      tomorrowRainProb: tomorrowDay ? tomorrowDay.maxRainProb : null,
      rainedTodayObserved: todayObservedRainMm >= 0.2 || currentPrecipMm >= 0.2
    },
    hourlySeries: hourlySeries.slice(-36), // recent 24h observed + next 12h forecast
    daily,
    warnings,
    sprayWindow: { status: sprayStatus, headline: sprayHeadline, headlineHi: sprayHeadlineHi },
    fetchedAt: new Date().toISOString()
  };
}

function temperatureCheck(t) {
  return Number.isFinite(t) && t > 35;
}

/**
 * Indian CPCB NAQI sub-index calculation for PM2.5 & PM10
 */
function calcLinearSubIndex(val, breakpoints) {
  if (!Number.isFinite(val) || val < 0) return null;
  for (const [cLow, cHigh, iLow, iHigh] of breakpoints) {
    if (val <= cHigh) {
      return Math.round(((iHigh - iLow) / (cHigh - cLow)) * (val - cLow) + iLow);
    }
  }
  return 500;
}

function getAqiCategory(aqi) {
  if (aqi == null) return { en: 'Unavailable', hi: 'उपलब्ध नहीं', level: 'unknown' };
  if (aqi <= 50) return { en: 'Good', hi: 'अच्छी', level: 'good' };
  if (aqi <= 100) return { en: 'Satisfactory', hi: 'संतोषजनक', level: 'satisfactory' };
  if (aqi <= 200) return { en: 'Moderate', hi: 'मध्यम', level: 'moderate' };
  if (aqi <= 300) return { en: 'Poor', hi: 'खराब', level: 'poor' };
  if (aqi <= 400) return { en: 'Very Poor', hi: 'बहुत खराब', level: 'very_poor' };
  return { en: 'Severe', hi: 'गंभीर', level: 'severe' };
}

export async function fetchRealAirQuality(lat, lon) {
  const latitude = Number(lat);
  const longitude = Number(lon);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    throw new Error('Valid latitude and longitude are required for AQI retrieval.');
  }

  const url = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${latitude}&longitude=${longitude}&current=pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,ozone,european_aqi,us_aqi&hourly=pm2_5,pm10,us_aqi&forecast_days=2&timezone=auto`;
  const resp = await fetch(url, { signal: AbortSignal.timeout(12000) });
  if (!resp.ok) {
    throw new Error(`Open-Meteo Air Quality API returned HTTP ${resp.status}.`);
  }
  const data = await resp.json();
  const cur = data.current || {};

  const pm25 = cur.pm2_5 ?? null;
  const pm10 = cur.pm10 ?? null;

  const pm25Sub = calcLinearSubIndex(pm25, [
    [0, 30, 0, 50],
    [30.1, 60, 51, 100],
    [60.1, 90, 101, 200],
    [90.1, 120, 201, 300],
    [120.1, 250, 301, 400],
    [250.1, 500, 401, 500]
  ]);
  const pm10Sub = calcLinearSubIndex(pm10, [
    [0, 50, 0, 50],
    [51, 100, 51, 100],
    [101, 250, 101, 200],
    [251, 350, 201, 300],
    [351, 430, 301, 400],
    [431, 600, 401, 500]
  ]);

  const indianNaqi = Math.max(pm25Sub ?? 0, pm10Sub ?? 0) || cur.us_aqi || null;
  const category = getAqiCategory(indianNaqi);

  const hourlyTimes = data.hourly?.time || [];
  const hourlyUsAqi = data.hourly?.us_aqi || [];
  const hourlyPm25 = data.hourly?.pm2_5 || [];
  const trend = hourlyTimes.slice(0, 24).map((t, i) => ({
    time: t,
    usAqi: hourlyUsAqi[i] ?? null,
    pm25: hourlyPm25[i] ?? null
  }));

  return {
    provider: 'Open-Meteo Air Quality API (Copernicus CAMS)',
    coordinates: { lat: latitude, lon: longitude },
    observationTime: cur.time || new Date().toISOString(),
    indianNaqi,
    usAqi: cur.us_aqi ?? null,
    europeanAqi: cur.european_aqi ?? null,
    category,
    pollutants: {
      pm25,
      pm10,
      no2: cur.nitrogen_dioxide ?? null,
      ozone: cur.ozone ?? null,
      co: cur.carbon_monoxide ?? null
    },
    trend,
    fetchedAt: new Date().toISOString()
  };
}
