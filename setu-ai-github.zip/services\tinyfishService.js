/**
 * Real TinyFish Web Research, Fetch & Browser Automation Service.
 * Zero simulated or hardcoded fallback results: if TINYFISH_API_KEY is missing
 * or upstream fails/blocks, throws an explicit structured error.
 */

const SEARCH_URL = 'https://api.search.tinyfish.ai';
const FETCH_URL = 'https://api.fetch.tinyfish.ai';
const AGENT_SSE_URL = 'https://agent.tinyfish.ai/v1/automation/run-sse';

export class TinyFishConfigError extends Error {
  constructor(message) {
    super(message);
    this.name = 'TinyFishConfigError';
    this.statusCode = 503;
  }
}

function requireApiKey() {
  const key = (process.env.TINYFISH_API_KEY || '').trim();
  if (!key) {
    throw new TinyFishConfigError(
      'TINYFISH_API_KEY is not configured. Add TINYFISH_API_KEY to .env to enable live TinyFish web research.'
    );
  }
  return key;
}

export async function tinyfishSearch(query, options = {}) {
  const apiKey = requireApiKey();
  const url = new URL(SEARCH_URL);
  url.searchParams.set('query', query);
  url.searchParams.set('location', options.location || 'IN');
  url.searchParams.set('language', options.language || 'en');
  if (options.include_domains) {
    url.searchParams.set('include_domains', options.include_domains);
  }

  const resp = await fetch(url, {
    headers: {
      'X-API-Key': apiKey,
      'Accept': 'application/json'
    },
    signal: AbortSignal.timeout(25000)
  });

  const text = await resp.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    json = { raw: text };
  }

  if (!resp.ok) {
    throw new Error(`TinyFish Search returned HTTP ${resp.status}: ${text.slice(0, 300)}`);
  }

  const rawItems =
    json?.results ||
    json?.data?.results ||
    json?.organic_results ||
    json?.items ||
    (Array.isArray(json) ? json : []);

  const items = rawItems
    .filter(x => x && (x.url || x.link))
    .map(x => ({
      title: x.title || x.name || x.url || x.link,
      url: x.url || x.link,
      snippet: x.snippet || x.description || '',
      siteName: x.site_name || '',
      date: x.date || null
    }));

  return { query, items, retrievedAt: new Date().toISOString() };
}

export async function tinyfishFetch(urls) {
  const apiKey = requireApiKey();
  const cleanUrls = [...new Set(urls.filter(u => /^https?:\/\//i.test(u)))].slice(0, 5);
  if (cleanUrls.length === 0) {
    return { results: [], errors: [{ error: 'No valid HTTP/HTTPS URLs to fetch.' }] };
  }

  const resp = await fetch(FETCH_URL, {
    method: 'POST',
    headers: {
      'X-API-Key': apiKey,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify({
      urls: cleanUrls,
      format: 'markdown',
      per_url_timeout_ms: 25000
    }),
    signal: AbortSignal.timeout(45000)
  });

  const text = await resp.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    json = { raw: text };
  }

  if (!resp.ok) {
    throw new Error(`TinyFish Fetch returned HTTP ${resp.status}: ${text.slice(0, 300)}`);
  }

  const results = (json?.results || []).map(r => ({
    url: r.final_url || r.url,
    title: r.title || r.url,
    text: (r.text || '').slice(0, 8000),
    retrievedAt: new Date().toISOString()
  }));

  const errors = (json?.errors || []).map(e => ({
    url: e.url,
    error: e.error || e.message || 'Source inaccessible or blocked'
  }));

  return { results, errors };
}

export async function streamTinyfishAutomation({ url, goal, onEvent, signal }) {
  const apiKey = requireApiKey();

  const resp = await fetch(AGENT_SSE_URL, {
    method: 'POST',
    headers: {
      'X-API-Key': apiKey,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      url,
      goal,
      browser_profile: 'stealth',
      proxy_config: { enabled: true, country_code: 'IN' }
    }),
    signal
  });

  if (!resp.ok || !resp.body) {
    const errText = await resp.text().catch(() => '');
    throw new Error(`TinyFish Agent HTTP ${resp.status}: ${errText.slice(0, 300)}`);
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith('data:')) continue;
      const rawJson = trimmed.slice(5).trim();
      if (!rawJson || rawJson === '[DONE]') continue;
      try {
        const evt = JSON.parse(rawJson);
        onEvent(evt);
      } catch {
        // skip incomplete chunk
      }
    }
  }
}
