/**
 * Real Google Gemini Service (gemini-2.5-flash)
 * - Intelligent Tool Router (decides when to invoke Weather, AQI, TinyFish, or Soil/Field context)
 * - Real SSE Streaming & Standard Completion
 * - Full Hindi (Devanagari) & English fidelity
 * - Multimodal Soil OCR (Image + PDF), Plant Disease Vision, VayuSetu Guidance & Environmental Bridge
 */

const CANDIDATE_MODELS = [
  'gemini-2.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3-flash-preview',
  'gemini-2.5-flash'
];

export class GeminiConfigError extends Error {
  constructor(message) {
    super(message);
    this.name = 'GeminiConfigError';
    this.statusCode = 503;
  }
}

function requireGeminiKey() {
  const key = (process.env.GEMINI_API_KEY || '').trim();
  if (!key) {
    throw new GeminiConfigError(
      'GEMINI_API_KEY is not configured. Add GEMINI_API_KEY to .env to enable Gemini AI features.'
    );
  }
  return key;
}

async function callGemini({ contents, systemInstruction = null, responseSchema = null, temperature = 0.15, maxOutputTokens = 2048 }) {
  const apiKey = requireGeminiKey();
  let lastError = 'No Gemini models succeeded.';

  for (const model of CANDIDATE_MODELS) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;
    const generationConfig = { temperature, maxOutputTokens };
    if (model.startsWith('gemini-2.5')) {
      generationConfig.thinkingConfig = { thinkingBudget: 0 };
    }
    if (responseSchema) {
      generationConfig.responseMimeType = 'application/json';
      generationConfig.responseSchema = responseSchema;
    }

    const body = { contents, generationConfig };
    if (systemInstruction) body.systemInstruction = { parts: [{ text: systemInstruction }] };

    try {
      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(35000)
      });

      if (!resp.ok) {
        const errText = await resp.text().catch(() => '');
        lastError = `Gemini (${model}) HTTP ${resp.status}: ${errText.slice(0, 260)}`;
        if (resp.status === 429 || resp.status === 404 || resp.status >= 500) continue;
        throw new Error(lastError);
      }

      const json = await resp.json();
      const text = json?.candidates?.[0]?.content?.parts?.[0]?.text || '';
      if (responseSchema) return JSON.parse(text || '{}');
      return text.trim();
    } catch (err) {
      lastError = err.message;
    }
  }
  throw new Error(lastError);
}

function langLabel(code) {
  return code === 'hi' ? 'Hindi (हिन्दी, Devanagari script)' : 'English';
}

// ---------------- INTELLIGENT TOOL ROUTER FOR CHAT ----------------
export async function planChatTools({ message, history, memorySummary, activeModule, preferredLanguage }) {
  const prompt = `You are the SETU AI Tool Router. Analyze the user's message and decide which REAL server tools are needed.
Preferred UI language: "${preferredLanguage || 'en'}".
Active module: "${activeModule || 'general'}".
Saved user context: ${JSON.stringify(memorySummary)}
Recent conversation turns: ${JSON.stringify((history || []).slice(-4).map(m => ({ role: m.role, text: m.text?.slice(0, 200) })))}
User message: "${message}"

Rules:
1. responseLanguage: Return "hi" if user selected preferredLanguage="hi" OR wrote in Hindi/Devanagari OR wrote in Hinglish (e.g. "barish hui kya", "hindi me batao"), UNLESS they explicitly ask for English ("in English", "english please"). Otherwise "en".
2. Set needsWeather=true for questions about rain ("did it rain", "barish", "weather", "mausam", "forecast", "irrigate", "spray", "running outside").
3. Set needsAqi=true for questions about air quality, smog, pollution, PM2.5, running/exercising outside, masks, indoor air, VayuSetu.
4. Set needsTinyfish=true ONLY when current external/official web verification is needed (e.g., government schemes, smog advisories, official ICAR crop/pest circulars, subsidies, current news/policy). Do NOT enable TinyFish for simple general questions or pure weather/AQI checks unless official advisory verification is requested.
5. If needsTinyfish=true, provide a focused India-relevant search query in tinyfishQuery (include location/crop if known).
6. rememberFact: If the user explicitly asks you to remember something ("remember that I grow wheat", "yaad rakhna mere ghar me elderly hain"), extract that short concise fact string; otherwise null.
7. clarificationNeeded: Only set if the question critically depends on location (weather/AQI/local schemes) AND saved location is completely missing/null.`;

  const responseSchema = {
    type: 'OBJECT',
    properties: {
      module: { type: 'STRING', enum: ['kisan', 'vayu', 'weather', 'research', 'general'] },
      responseLanguage: { type: 'STRING', enum: ['en', 'hi'] },
      needsWeather: { type: 'BOOLEAN' },
      needsAqi: { type: 'BOOLEAN' },
      needsTinyfish: { type: 'BOOLEAN' },
      tinyfishQuery: { type: 'STRING', nullable: true },
      rememberFact: { type: 'STRING', nullable: true },
      rememberScope: { type: 'STRING', enum: ['shared', 'kisan', 'vayu'] },
      clarificationNeeded: { type: 'STRING', nullable: true }
    },
    required: ['module', 'responseLanguage', 'needsWeather', 'needsAqi', 'needsTinyfish', 'rememberScope']
  };

  return callGemini({
    contents: [{ parts: [{ text: prompt }] }],
    responseSchema,
    temperature: 0.05,
    maxOutputTokens: 500
  });
}

// ---------------- STREAMING GROUNDED CHAT ----------------
export async function streamGroundedChat({
  message,
  history,
  memorySummary,
  toolResults,
  imageBase64,
  mimeType,
  responseLanguage,
  onChunk,
  signal
}) {
  const apiKey = requireGeminiKey();
  const useHindi = responseLanguage === 'hi';

  const systemInstruction = `You are SETU AI — a warm, intelligent Environmental (VayuSetu) & Agricultural (KisanSetu) assistant.
CRITICAL LANGUAGE RULE:
${useHindi
    ? 'Respond ENTIRELY in natural, clear, simple Hindi (हिन्दी, Devanagari script). Explain technical terms (like AQI, PM2.5, NPK, pH) in simple Hindi. Do NOT randomly switch to English.'
    : 'Respond in clear, friendly English.'}

CRITICAL GROUNDING & HONESTY RULES:
1. Use ONLY the retrieved data, saved user memory, and deterministic calculations provided below.
2. Distinguish clearly between OBSERVED rainfall vs. FORECAST rainfall—never confuse forecast rain with rain that already fell. Include dates/timestamps and source names when quoting weather or AQI.
3. For citations: ONLY link to URLs that actually appear in toolResults.tinyfishSources. NEVER invent URLs.
4. For missing data (no soil report, no field area, no location): state plainly what is missing instead of guessing.
5. Safety: Never prescribe dangerous or unsupported chemical pesticide doses; recommend IPM and consulting a local KVK / Agriculture Officer.
6. Format nicely with Markdown headings, bullet lists, or compact Markdown tables when helpful.`;

  const contents = [];
  if (Array.isArray(history)) {
    for (const h of history.slice(-8)) {
      if (!h?.text) continue;
      contents.push({
        role: h.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: String(h.text) }]
      });
    }
  }

  const contextBlock = `Saved User & Module Context:\n${JSON.stringify(memorySummary, null, 2)}\n\nLive Retrieved Tool Outputs:\n${JSON.stringify(toolResults || {}, null, 2)}`;
  const userParts = [{ text: `${contextBlock}\n\nUser Question: ${message}` }];
  if (imageBase64) {
    userParts.push({
      inlineData: {
        mimeType: mimeType || 'image/jpeg',
        data: String(imageBase64).replace(/^data:[^;]+;base64,/, '')
      }
    });
  }
  contents.push({ role: 'user', parts: userParts });

  let resp = null;
  let lastStreamErr = 'Gemini stream failed.';
  for (const model of CANDIDATE_MODELS) {
    const streamUrl = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse&key=${encodeURIComponent(apiKey)}`;
    const genCfg = { temperature: 0.25, maxOutputTokens: 2048 };
    if (model.startsWith('gemini-2.5')) genCfg.thinkingConfig = { thinkingBudget: 0 };
    const attemptSignal = signal
      ? AbortSignal.any([signal, AbortSignal.timeout(35000)])
      : AbortSignal.timeout(35000);
    const attempt = await fetch(streamUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemInstruction }] },
        contents,
        generationConfig: genCfg
      }),
      signal: attemptSignal
    });
    if (attempt.ok && attempt.body) {
      resp = attempt;
      break;
    }
    const errText = await attempt.text().catch(() => '');
    lastStreamErr = `Gemini (${model}) stream HTTP ${attempt.status}: ${errText.slice(0, 240)}`;
    if (attempt.status !== 429 && attempt.status !== 404 && attempt.status < 500) break;
  }

  if (!resp || !resp.body) {
    throw new Error(lastStreamErr);
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let fullText = '';

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith('data:')) continue;
      const jsonStr = trimmed.slice(5).trim();
      if (!jsonStr || jsonStr === '[DONE]') continue;
      try {
        const parsed = JSON.parse(jsonStr);
        const piece = parsed?.candidates?.[0]?.content?.parts?.[0]?.text || '';
        if (piece) {
          fullText += piece;
          onChunk(piece);
        }
      } catch {
        // ignore partial SSE chunk
      }
    }
  }
  return fullText.trim();
}

// ---------------- VAYUSETU & ENVIRONMENTAL BRIDGE (SINGLE CALL) ----------------
export async function generateVayuAndBridge({ aqiData, weather, vayuMemory, farmContext, locationLabel, languageCode = 'en' }) {
  const lang = langLabel(languageCode);
  const prompt = `Generate BOTH VayuSetu air-quality protection guidance AND the Environmental Impact Bridge in ${lang}.
Base EVERY recommendation strictly on the real retrieved AQI & weather data below and the user's saved household/farm context. Never invent unproven causal claims.
Location: ${locationLabel || 'Not specified'}
Household & Schedule: ${JSON.stringify(vayuMemory || {})}
Farm Context: ${JSON.stringify(farmContext || {})}
Live AQI Data: ${JSON.stringify(aqiData)}
Live Weather Data: ${JSON.stringify(weather || null)}`;

  const responseSchema = {
    type: 'OBJECT',
    properties: {
      guidance: {
        type: 'OBJECT',
        properties: {
          headline: { type: 'STRING' },
          outdoorSafety: { type: 'STRING' },
          familyProtection: { type: 'STRING' },
          indoorAirGuidance: { type: 'STRING' },
          cleanerCommuting: { type: 'STRING' },
          dailyPlanTips: { type: 'ARRAY', items: { type: 'STRING' } }
        },
        required: ['headline', 'outdoorSafety', 'familyProtection', 'indoorAirGuidance', 'cleanerCommuting', 'dailyPlanTips']
      },
      bridge: {
        type: 'OBJECT',
        properties: {
          bridgeSummary: { type: 'STRING' },
          weatherToAirLink: { type: 'STRING' },
          farmAndEnvironmentLink: { type: 'STRING' },
          sharedRecommendations: { type: 'ARRAY', items: { type: 'STRING' } }
        },
        required: ['bridgeSummary', 'weatherToAirLink', 'farmAndEnvironmentLink', 'sharedRecommendations']
      }
    },
    required: ['guidance', 'bridge']
  };

  return callGemini({
    contents: [{ parts: [{ text: prompt }] }],
    responseSchema,
    temperature: 0.2
  });
}

// ---------------- KISANSETU MODULE METHODS (ALL LANGUAGE-AWARE) ----------------
export async function extractSoilReport({ base64Data, mimeType, languageCode = 'en' }) {
  const cleanData = String(base64Data || '').replace(/^data:[^;]+;base64,/, '');
  if (!cleanData) throw new Error('Soil report file data is required.');
  const lang = langLabel(languageCode);

  const prompt = `Parse this Indian Soil Health Card / soil lab report carefully.
Write qualityNote, plainLanguageSummary, and parameterExplanations in ${lang}.
NEVER invent missing values: set missing or unreadable fields to null.`;

  const responseSchema = {
    type: 'OBJECT',
    properties: {
      reportDetected: { type: 'BOOLEAN' },
      qualityNote: { type: 'STRING' },
      cropMentioned: { type: 'STRING', nullable: true },
      parameters: {
        type: 'OBJECT',
        properties: {
          ph: { type: 'NUMBER', nullable: true },
          ec: { type: 'NUMBER', nullable: true },
          organicCarbon: { type: 'NUMBER', nullable: true },
          nitrogen: { type: 'NUMBER', nullable: true },
          phosphorus: { type: 'NUMBER', nullable: true },
          potassium: { type: 'NUMBER', nullable: true },
          sulphur: { type: 'NUMBER', nullable: true },
          zinc: { type: 'NUMBER', nullable: true },
          iron: { type: 'NUMBER', nullable: true },
          boron: { type: 'NUMBER', nullable: true }
        }
      },
      otherParameters: {
        type: 'ARRAY',
        items: {
          type: 'OBJECT',
          properties: {
            name: { type: 'STRING' },
            value: { type: 'STRING' },
            unit: { type: 'STRING', nullable: true }
          },
          required: ['name', 'value']
        }
      },
      printedRecommendations: {
        type: 'OBJECT',
        properties: {
          nKgHa: { type: 'NUMBER', nullable: true },
          pKgHa: { type: 'NUMBER', nullable: true },
          kKgHa: { type: 'NUMBER', nullable: true }
        }
      },
      unreliableFields: { type: 'ARRAY', items: { type: 'STRING' } },
      plainLanguageSummary: { type: 'STRING' },
      parameterExplanations: {
        type: 'ARRAY',
        items: {
          type: 'OBJECT',
          properties: { parameter: { type: 'STRING' }, meaning: { type: 'STRING' } },
          required: ['parameter', 'meaning']
        }
      }
    },
    required: ['reportDetected', 'qualityNote', 'parameters', 'otherParameters', 'unreliableFields', 'plainLanguageSummary', 'parameterExplanations']
  };

  return callGemini({
    contents: [{ parts: [{ text: prompt }, { inlineData: { mimeType: mimeType || 'image/jpeg', data: cleanData } }] }],
    responseSchema,
    temperature: 0.1
  });
}

export async function analyzeCropDisease({ base64Data, mimeType, cropHint, notes, languageCode = 'en' }) {
  const cleanData = String(base64Data || '').replace(/^data:[^;]+;base64,/, '');
  if (!cleanData) throw new Error('Plant or leaf image is required.');
  const lang = langLabel(languageCode);

  const prompt = `Analyze this plant/crop/pest image in ${lang}.
Crop hint: "${cropHint || 'Not specified'}", Notes: "${notes || 'None'}".
If blurry/unclear, set imageQuality="poor" and ask for a clearer photo. Never claim lab certainty or prescribe unsupported chemical pesticides.`;

  const responseSchema = {
    type: 'OBJECT',
    properties: {
      imageQuality: { type: 'STRING', enum: ['clear', 'moderate', 'poor'] },
      imageQualityFeedback: { type: 'STRING' },
      likelyCrop: { type: 'STRING' },
      visibleSymptoms: { type: 'ARRAY', items: { type: 'STRING' } },
      possibleCauses: { type: 'ARRAY', items: { type: 'STRING' } },
      potentialIdentifications: {
        type: 'ARRAY',
        items: {
          type: 'OBJECT',
          properties: {
            name: { type: 'STRING' },
            category: { type: 'STRING' },
            confidence: { type: 'STRING', enum: ['low', 'moderate', 'high'] },
            uncertaintyNote: { type: 'STRING' }
          },
          required: ['name', 'category', 'confidence', 'uncertaintyNote']
        }
      },
      additionalInfoNeeded: { type: 'ARRAY', items: { type: 'STRING' } },
      recommendedNextSteps: { type: 'ARRAY', items: { type: 'STRING' } },
      preventionSuggestions: { type: 'ARRAY', items: { type: 'STRING' } },
      safetyCaution: { type: 'STRING' }
    },
    required: ['imageQuality', 'imageQualityFeedback', 'likelyCrop', 'visibleSymptoms', 'possibleCauses', 'potentialIdentifications', 'additionalInfoNeeded', 'recommendedNextSteps', 'preventionSuggestions', 'safetyCaution']
  };

  return callGemini({
    contents: [{ parts: [{ text: prompt }, { inlineData: { mimeType: mimeType || 'image/jpeg', data: cleanData } }] }],
    responseSchema,
    temperature: 0.15
  });
}

export async function recommendCrops({ input, retrievedSources, languageCode = 'en' }) {
  const lang = langLabel(languageCode);
  const prompt = `Provide transparent AI crop suitability guidance in ${lang}.
Do NOT pretend this is a scientific yield prediction model. Disclose missing information and limitations.
Inputs: ${JSON.stringify(input)}
Retrieved Sources: ${JSON.stringify(retrievedSources || [])}`;

  const responseSchema = {
    type: 'OBJECT',
    properties: {
      modelCaveat: { type: 'STRING' },
      missingInformation: { type: 'ARRAY', items: { type: 'STRING' } },
      recommendations: {
        type: 'ARRAY',
        items: {
          type: 'OBJECT',
          properties: {
            cropName: { type: 'STRING' },
            suitabilityLevel: { type: 'STRING', enum: ['High', 'Moderate', 'Conditional'] },
            reasons: { type: 'ARRAY', items: { type: 'STRING' } },
            conditionsRequired: { type: 'ARRAY', items: { type: 'STRING' } },
            potentialLimitations: { type: 'ARRAY', items: { type: 'STRING' } }
          },
          required: ['cropName', 'suitabilityLevel', 'reasons', 'conditionsRequired', 'potentialLimitations']
        }
      }
    },
    required: ['modelCaveat', 'missingInformation', 'recommendations']
  };

  return callGemini({
    contents: [{ parts: [{ text: prompt }] }],
    responseSchema,
    temperature: 0.2
  });
}

export async function interpretWeather({ weather, crop, location, languageCode = 'en' }) {
  const lang = langLabel(languageCode);
  const prompt = `Interpret this REAL observed rainfall, forecast rainfall, and weather data in ${lang}.
Location: ${location || 'Not set'}, Crop: ${crop || 'General'}.
Explicitly distinguish observed past/today rainfall from forecast rainfall. Do NOT invent weather values.
Weather: ${JSON.stringify(weather)}`;

  const responseSchema = {
    type: 'OBJECT',
    properties: {
      rainSummary: { type: 'STRING' },
      irrigationGuidance: { type: 'STRING' },
      rainPrecautions: { type: 'STRING' },
      heatStressAssessment: { type: 'STRING' },
      sprayingGuidance: { type: 'STRING' }
    },
    required: ['rainSummary', 'irrigationGuidance', 'rainPrecautions', 'heatStressAssessment', 'sprayingGuidance']
  };

  return callGemini({
    contents: [{ parts: [{ text: prompt }] }],
    responseSchema,
    temperature: 0.2
  });
}

export async function synthesizeSchemes({ filters, fetchedDocs, searchItems, languageCode = 'en' }) {
  const lang = langLabel(languageCode);
  const prompt = `Extract government scheme details in ${lang} STRICTLY from the retrieved pages/snippets below.
NEVER invent schemes, deadlines, or amounts. Mark missing details as "Unverified — check official link".
Filters: ${JSON.stringify(filters)}
Docs: ${JSON.stringify(fetchedDocs)}
Snippets: ${JSON.stringify(searchItems)}`;

  const responseSchema = {
    type: 'OBJECT',
    properties: {
      overviewNote: { type: 'STRING' },
      schemes: {
        type: 'ARRAY',
        items: {
          type: 'OBJECT',
          properties: {
            schemeName: { type: 'STRING' },
            officialSource: { type: 'STRING' },
            eligibility: { type: 'STRING' },
            benefits: { type: 'STRING' },
            applicationProcess: { type: 'STRING' },
            requiredDocuments: { type: 'ARRAY', items: { type: 'STRING' } },
            sourceUrl: { type: 'STRING' },
            verificationStatus: { type: 'STRING', enum: ['Retrieved from Official/Public Page', 'Snippet Only — Unverified Details'] }
          },
          required: ['schemeName', 'officialSource', 'eligibility', 'benefits', 'applicationProcess', 'requiredDocuments', 'sourceUrl', 'verificationStatus']
        }
      }
    },
    required: ['overviewNote', 'schemes']
  };

  return callGemini({
    contents: [{ parts: [{ text: prompt }] }],
    responseSchema,
    temperature: 0.1
  });
}

export async function synthesizeResearch({ query, fetchedDocs, fetchErrors, searchItems, languageCode = 'en' }) {
  const lang = langLabel(languageCode);
  const prompt = `Summarize research findings in ${lang} STRICTLY from the retrieved TinyFish pages below.
Cite ONLY URLs present in the retrieved docs or snippets below. Report inaccessible/blocked pages honestly.
Query: "${query}"
Docs: ${JSON.stringify(fetchedDocs)}
Snippets: ${JSON.stringify(searchItems)}
Errors: ${JSON.stringify(fetchErrors || [])}`;

  const responseSchema = {
    type: 'OBJECT',
    properties: {
      executiveSummary: { type: 'STRING' },
      keyFindings: { type: 'ARRAY', items: { type: 'STRING' } },
      actionItems: { type: 'ARRAY', items: { type: 'STRING' } },
      limitationsAndGaps: { type: 'STRING' },
      citations: {
        type: 'ARRAY',
        items: {
          type: 'OBJECT',
          properties: { title: { type: 'STRING' }, url: { type: 'STRING' }, relevance: { type: 'STRING' } },
          required: ['title', 'url', 'relevance']
        }
      }
    },
    required: ['executiveSummary', 'keyFindings', 'actionItems', 'limitationsAndGaps', 'citations']
  };

  return callGemini({
    contents: [{ parts: [{ text: prompt }] }],
    responseSchema,
    temperature: 0.15
  });
}
