/**
 * KisanSetu AI — Deterministic Agronomy & Area Calculator
 * Strictly separates Gemini extraction from verifiable arithmetic.
 */
window.KisanCalc = (function () {
  const SQM_PER_ACRE = 4046.8564224;
  const SQM_PER_HECTARE = 10000;
  const HA_PER_ACRE = 0.40468564224;

  function computeAreas(sqm, bighaSqm) {
    const safeSqm = Math.max(0, Number(sqm) || 0);
    const safeBigha = Math.max(100, Number(bighaSqm) || 2529.29);
    const acres = safeSqm / SQM_PER_ACRE;
    const hectares = safeSqm / SQM_PER_HECTARE;
    const bighas = safeSqm / safeBigha;
    return {
      sqm: safeSqm,
      acres,
      hectares,
      bighas,
      bighaSqm: safeBigha,
    };
  }

  /**
   * Adjusts NPK target dose based on Soil Health Card values if printed doses are absent.
   * Uses standard Indian soil fertility rating adjustments (+/- 25% of ICAR baseline).
   */
  function resolveTargetDoseKgHa(cropInfo, shc) {
    const baseN = cropInfo.nKgHa;
    const baseP = cropInfo.pKgHa;
    const baseK = cropInfo.kKgHa;

    const hasPrinted =
      Number.isFinite(Number(shc.printedNDoseKgHa)) &&
      Number(shc.printedNDoseKgHa) > 0;

    if (hasPrinted) {
      return {
        nDose: Number(shc.printedNDoseKgHa),
        pDose: Number(shc.printedPDoseKgHa ?? baseP),
        kDose: Number(shc.printedKDoseKgHa ?? baseK),
        sourceLabel: "Printed Soil Health Card Recommended Dose",
      };
    }

    // Adjust ICAR baseline gently by available NPK reading (kg/ha)
    let nFactor = 1.0;
    if (Number.isFinite(Number(shc.nValue))) {
      const n = Number(shc.nValue);
      if (n < 280) nFactor = 1.15; // Low N -> +15%
      else if (n > 560) nFactor = 0.8; // High N -> -20%
    }

    let pFactor = 1.0;
    if (Number.isFinite(Number(shc.pValue))) {
      const p = Number(shc.pValue);
      if (p < 10) pFactor = 1.15;
      else if (p > 25) pFactor = 0.8;
    }

    let kFactor = 1.0;
    if (Number.isFinite(Number(shc.kValue))) {
      const k = Number(shc.kValue);
      if (k < 108) kFactor = 1.15;
      else if (k > 280) kFactor = 0.8;
    }

    return {
      nDose: Math.round(baseN * nFactor),
      pDose: Math.round(baseP * pFactor),
      kDose: Math.round(baseK * kFactor),
      sourceLabel: `${cropInfo.source} (adjusted for soil test N/P/K status)`,
    };
  }

  function calculatePrescription({
    effectiveHectares,
    cropName,
    cropsData,
    shcValues,
  }) {
    const cropInfo = cropsData[cropName] || cropsData.Wheat;
    const areaHa = Math.max(0.01, Number(effectiveHectares) || 0.4047);

    const dose = resolveTargetDoseKgHa(cropInfo, shcValues || {});

    // 1. DAP (18-46-0) satisfies P2O5 first
    const totalP2O5Kg = dose.pDose * areaHa;
    const dapKg = totalP2O5Kg / 0.46;
    const dapBags50kg = dapKg / 50;

    // 2. N supplied by DAP (18%) reduces Urea requirement
    const nFromDapKg = dapKg * 0.18;
    const totalNKg = dose.nDose * areaHa;
    const remainingNKg = Math.max(0, totalNKg - nFromDapKg);
    const ureaKg = remainingNKg / 0.46;
    const ureaBags50kg = ureaKg / 50;

    // 3. MOP (0-0-60) satisfies K2O
    const totalK2OKg = dose.kDose * areaHa;
    const mopKg = totalK2OKg / 0.6;
    const mopBags50kg = mopKg / 50;

    // 4. Seed & Yield Range (only with explicit assumptions)
    const seedKg = cropInfo.seedKgHa * areaHa;
    const yieldMinQ = cropInfo.yieldRangeQHa[0] * areaHa;
    const yieldMaxQ = cropInfo.yieldRangeQHa[1] * areaHa;

    const formulas = [
      `Effective Cultivated Area = ${areaHa.toFixed(3)} ha (${(
        areaHa / HA_PER_ACRE
      ).toFixed(2)} acres)`,
      `DAP (50 kg bags) = (${dose.pDose} kg P₂O₅/ha ÷ 0.46) × ${areaHa.toFixed(
        3
      )} ha ÷ 50 = ${dapBags50kg.toFixed(2)} bags (${dapKg.toFixed(1)} kg)`,
      `N credited from DAP = ${dapKg.toFixed(
        1
      )} kg × 0.18 = ${nFromDapKg.toFixed(1)} kg N`,
      `Remaining N = max(0, (${dose.nDose} × ${areaHa.toFixed(
        3
      )}) − ${nFromDapKg.toFixed(1)}) = ${remainingNKg.toFixed(1)} kg N`,
      `Urea (50 kg bags) = (${remainingNKg.toFixed(
        1
      )} kg ÷ 0.46) ÷ 50 = ${ureaBags50kg.toFixed(2)} bags (${ureaKg.toFixed(
        1
      )} kg)`,
      `MOP (50 kg bags) = (${dose.kDose} kg K₂O/ha ÷ 0.60) × ${areaHa.toFixed(
        3
      )} ha ÷ 50 = ${mopBags50kg.toFixed(2)} bags (${mopKg.toFixed(1)} kg)`,
    ];

    return {
      cropName,
      season: cropInfo.season,
      areaHa,
      dose,
      dapKg,
      dapBags: dapBags50kg,
      nFromDapKg,
      ureaKg,
      ureaBags: ureaBags50kg,
      mopKg,
      mopBags: mopBags50kg,
      seedKg,
      yieldRangeQ: [yieldMinQ, yieldMaxQ],
      assumptions: cropInfo.assumptions,
      formulas,
    };
  }

  return {
    computeAreas,
    calculatePrescription,
    HA_PER_ACRE,
    SQM_PER_ACRE,
  };
})();
