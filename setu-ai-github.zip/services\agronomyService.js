import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const loadJson = (file) => JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', file), 'utf8'));

export const STATES_DATA = loadJson('states.json');
export const CROPS_DATA = loadJson('crops.json');
export const PESTS_DATA = loadJson('pests.json');
export const LANGUAGES_DATA = loadJson('languages.json');
export const MARKETS_DATA = loadJson('markets.json');

export const SQM_PER_ACRE = 4046.8564224;
export const SQM_PER_HECTARE = 10000;

export function matchStateMeta(rawState) {
  if (!rawState) return { key: 'Default', ...STATES_DATA.Default };
  const lower = String(rawState).toLowerCase();
  for (const key of Object.keys(STATES_DATA)) {
    if (key === 'Default') continue;
    if (lower.includes(key.toLowerCase())) {
      return { key, ...STATES_DATA[key] };
    }
  }
  return { key: rawState, ...STATES_DATA.Default };
}

/**
 * Deterministic fertilizer calculation using ONLY explicit source doses
 * (either printed on Soil Health Card or curated ICAR general baselines).
 * Never fabricates recommendations for unsupported crops.
 */
export function calculateFertilizerPlan({ areaHectares, cropName, soilParams = {}, printedDoses = {} }) {
  const areaHa = Number(areaHectares);
  if (!Number.isFinite(areaHa) || areaHa <= 0) {
    throw new Error('A valid field area (> 0 hectares) is required.');
  }

  const cropInfo = CROPS_DATA[cropName];
  const hasPrinted = Number(printedDoses.nKgHa) > 0 || Number(printedDoses.pKgHa) > 0 || Number(printedDoses.kKgHa) > 0;

  if (!cropInfo && !hasPrinted) {
    return {
      supported: false,
      missingInformation: [`No curated ICAR baseline found for "${cropName}" and no printed Soil Health Card recommended dose was provided.`],
      recommendationSource: 'Unavailable — use TinyFish Official Source Lookup or enter printed SHC doses.'
    };
  }

  let nDose, pDose, kDose, sourceType, sourceCitation;
  if (hasPrinted) {
    nDose = Number(printedDoses.nKgHa) || 0;
    pDose = Number(printedDoses.pKgHa) || 0;
    kDose = Number(printedDoses.kKgHa) || 0;
    sourceType = 'User-Verified Printed Soil Health Card Dose';
    sourceCitation = 'Printed Soil Health Card recommendation entered/verified by user';
  } else {
    // Adjust ICAR baseline conservatively only if soil test N/P/K is actually provided
    let nFactor = 1.0, pFactor = 1.0, kFactor = 1.0;
    const notes = [];
    if (Number.isFinite(Number(soilParams.nitrogen)) && soilParams.nitrogen !== null && soilParams.nitrogen !== '') {
      const n = Number(soilParams.nitrogen);
      if (n < 280) { nFactor = 1.15; notes.push('Low soil N (<280 kg/ha) -> +15% N adjustment'); }
      else if (n > 560) { nFactor = 0.80; notes.push('High soil N (>560 kg/ha) -> -20% N adjustment'); }
    }
    if (Number.isFinite(Number(soilParams.phosphorus)) && soilParams.phosphorus !== null && soilParams.phosphorus !== '') {
      const p = Number(soilParams.phosphorus);
      if (p < 10) { pFactor = 1.15; notes.push('Low soil P (<10 kg/ha) -> +15% P adjustment'); }
      else if (p > 25) { pFactor = 0.80; notes.push('High soil P (>25 kg/ha) -> -20% P adjustment'); }
    }
    if (Number.isFinite(Number(soilParams.potassium)) && soilParams.potassium !== null && soilParams.potassium !== '') {
      const k = Number(soilParams.potassium);
      if (k < 108) { kFactor = 1.15; notes.push('Low soil K (<108 kg/ha) -> +15% K adjustment'); }
      else if (k > 280) { kFactor = 0.80; notes.push('High soil K (>280 kg/ha) -> -20% K adjustment'); }
    }
    nDose = Math.round(cropInfo.nKgHa * nFactor);
    pDose = Math.round(cropInfo.pKgHa * pFactor);
    kDose = Math.round(cropInfo.kKgHa * kFactor);
    sourceType = 'Curated ICAR Baseline + Deterministic Soil Rating Adjustment';
    sourceCitation = `${cropInfo.source}${notes.length ? ` (${notes.join('; ')})` : ''}`;
  }

  const totalP2O5Kg = pDose * areaHa;
  const dapKg = totalP2O5Kg / 0.46;
  const dapBags = dapKg / 50;

  const nFromDapKg = dapKg * 0.18;
  const totalNKg = nDose * areaHa;
  const remainingNKg = Math.max(0, totalNKg - nFromDapKg);
  const ureaKg = remainingNKg / 0.46;
  const ureaBags = ureaKg / 50;

  const totalK2OKg = kDose * areaHa;
  const mopKg = totalK2OKg / 0.60;
  const mopBags = mopKg / 50;

  const missingInformation = [];
  if (soilParams.nitrogen == null || soilParams.nitrogen === '') missingInformation.push('Available Nitrogen (N)');
  if (soilParams.phosphorus == null || soilParams.phosphorus === '') missingInformation.push('Available Phosphorus (P)');
  if (soilParams.potassium == null || soilParams.potassium === '') missingInformation.push('Available Potassium (K)');
  if (soilParams.ph == null || soilParams.ph === '') missingInformation.push('Soil pH');

  return {
    supported: true,
    cropName,
    areaHectares: areaHa,
    targetDoseKgHa: { n: nDose, p2o5: pDose, k2o: kDose },
    sourceType,
    sourceCitation,
    quantities: {
      dapKg: Number(dapKg.toFixed(1)),
      dapBags50kg: Number(dapBags.toFixed(2)),
      nCreditedFromDapKg: Number(nFromDapKg.toFixed(1)),
      ureaKg: Number(ureaKg.toFixed(1)),
      ureaBags50kg: Number(ureaBags.toFixed(2)),
      mopKg: Number(mopKg.toFixed(1)),
      mopBags50kg: Number(mopBags.toFixed(2)),
      seedKg: cropInfo ? Number((cropInfo.seedKgHa * areaHa).toFixed(1)) : null
    },
    assumptions: [
      'DAP grade assumed: 18-46-0 (18% N, 46% P₂O₅); Urea: 46-0-0 (46% N); MOP: 0-0-60 (60% K₂O).',
      'Standard 50 kg bag weight used for bag count calculations.',
      'Field area is map-estimated; verify soil-specific micronutrients (Zinc/Sulphur/Boron) with your local KVK.'
    ],
    formulas: [
      `DAP (kg) = (${pDose} kg P₂O₅/ha × ${areaHa.toFixed(3)} ha) ÷ 0.46 = ${dapKg.toFixed(1)} kg (${dapBags.toFixed(2)} bags)`,
      `N credited from DAP = ${dapKg.toFixed(1)} kg × 0.18 = ${nFromDapKg.toFixed(1)} kg N`,
      `Remaining N = max(0, (${nDose} × ${areaHa.toFixed(3)}) − ${nFromDapKg.toFixed(1)}) = ${remainingNKg.toFixed(1)} kg N`,
      `Urea (kg) = ${remainingNKg.toFixed(1)} ÷ 0.46 = ${ureaKg.toFixed(1)} kg (${ureaBags.toFixed(2)} bags)`,
      `MOP (kg) = (${kDose} kg K₂O/ha × ${areaHa.toFixed(3)} ha) ÷ 0.60 = ${mopKg.toFixed(1)} kg (${mopBags.toFixed(2)} bags)`
    ],
    missingInformation
  };
}
