/* SETU AI — Unified Ecosystem Frontend Controller */
const App = (function () {
  let ws = null;
  let health = {};
  let meta = { crops: {}, languages: [] };
  let liveWeather = null;
  let liveAqi = null;
  let activeConvId = null;
  let chatAttachment = null;
  let chatAbortController = null;
  let voiceRec = null;
  let voiceActive = false;

  let kMap = null;
  let kDrawn = null;
  let kActiveGeo = null;
  let kActiveArea = { sqm: 0, acres: 0, hectares: 0, centroid: null, locationNote: '' };
  let rainChart = null;

  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));

  function toast(msg) {
    const c = $('#toastContainer');
    const d = document.createElement('div');
    d.className = 'toast';
    d.textContent = msg;
    c.appendChild(d);
    setTimeout(() => d.remove(), 3400);
  }

  async function api(url, opts = {}) {
    const r = await fetch(url, {
      ...opts,
      headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) }
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || `HTTP ${r.status}`);
    return d;
  }

  // ---------------- INIT ----------------
  async function init() {
    await Promise.all([loadHealth(), loadMeta(), refreshWorkspace()]);
    populateCropSelects();

    const savedLang = ws?.shared?.preferredLanguage || localStorage.getItem('setu_lang') || 'en';
    applyLanguageLocally(savedLang);

    // Ensure at least one conversation exists
    if (!ws.conversations.length) {
      await startNewChat(false);
    } else {
      activeConvId = ws.conversations[0].id;
    }

    renderAll();

    // Auto-fetch live weather & AQI if location is already saved!
    if (getActiveLoc()) {
      refreshMySetuLive();
    }
  }

  async function loadHealth() {
    try {
      health = await api('/api/health');
      $('#sidebar-api-health').innerHTML = `
        Gemini: <b>${health.geminiConfigured ? 'Ready' : 'Missing'}</b> · TinyFish: <b>${health.tinyfishConfigured ? 'Ready' : 'Missing'}</b>
      `;
    } catch {
      $('#sidebar-api-health').textContent = 'API health unavailable';
    }
  }

  async function loadMeta() {
    try { meta = await api('/api/meta'); } catch { meta = { crops: { Wheat: {}, Rice: {} } }; }
  }

  async function refreshWorkspace() {
    const res = await api('/api/workspace');
    ws = res.workspace;
  }

  function populateCropSelects() {
    const opts = Object.keys(meta.crops || {}).map(c => `<option value="${esc(c)}">${esc(c)} (${esc(meta.crops[c].season || '')})</option>`).join('');
    ['#k-field-crop', '#f-crop'].forEach(sel => {
      const el = $(sel);
      if (el) el.innerHTML = `<option value="">Select crop...</option>` + opts;
    });
  }

  function getActiveLoc() {
    return ws?.shared?.location || ws?.shared?.farmLocation || ws?.kisanMemory?.fields?.[0]?.centroid || null;
  }

  // ---------------- LANGUAGE (REAL HINDI + PERSISTENCE) ----------------
  function applyLanguageLocally(code) {
    const lang = code === 'hi' ? 'hi' : 'en';
    localStorage.setItem('setu_lang', lang);
    SetuI18n.setLang(lang);
    $('#lang-btn-en').classList.toggle('active', lang === 'en');
    $('#lang-btn-hi').classList.toggle('active', lang === 'hi');
    $('#chat-lang-pill').textContent = lang === 'hi' ? 'हिन्दी' : 'English';
  }

  async function changeLanguage(code) {
    applyLanguageLocally(code);
    try {
      const res = await api('/api/settings', { method: 'PUT', body: JSON.stringify({ shared: { preferredLanguage: code } }) });
      ws = res.workspace;
      renderAll();
      toast(code === 'hi' ? 'भाषा हिन्दी में बदली गई' : 'Language switched to English');
    } catch (e) {
      toast(e.message);
    }
  }

  // ---------------- NAVIGATION ----------------
  function showView(viewId) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    document.querySelectorAll('.nav-link').forEach(n => n.classList.remove('active'));
    $(`#view-${viewId}`)?.classList.add('active');
    $(`.nav-link[data-view="${viewId}"]`)?.classList.add('active');
    toggleSidebar(false);

    if (viewId === 'kisansetu') {
      setTimeout(() => { ensureKisanMap(); kMap?.invalidateSize(); }, 60);
    }
    if (viewId === 'chat') renderChatView();
    if (viewId === 'weather' && liveWeather) renderWeatherView(liveWeather, null);
  }

  function switchModule(mod) {
    $('#pill-kisan').classList.toggle('active', mod === 'kisansetu');
    $('#pill-vayu').classList.toggle('active', mod === 'vayusetu');
    showView(mod);
  }

  function openKisanSub(sub) {
    showView('kisansetu');
    document.querySelectorAll('.subtab').forEach(b => b.classList.toggle('active', b.dataset.ksub === sub));
    document.querySelectorAll('.ksub-pane').forEach(p => p.classList.toggle('active', p.id === `ksub-${sub}`));
    if (sub === 'map') setTimeout(() => { ensureKisanMap(); kMap?.invalidateSize(); }, 60);
  }

  function toggleSidebar(open) {
    $('#setuSidebar').classList.toggle('open', open);
  }

  // ---------------- RENDER ALL ----------------
  function renderAll() {
    renderTopbarAndSidebar();
    renderMySetu();
    renderSavedFields();
    renderNotifications();
    renderSavedItems();
    renderMonitoring();
    renderSettingsForm();
    renderChatView();
  }

  function renderTopbarAndSidebar() {
    const loc = getActiveLoc();
    const lang = SetuI18n.getLang();
    $('#topbar-location').textContent = loc?.label || (lang === 'hi' ? 'स्थान सहेजा नहीं गया' : 'Set Location');
    const unread = (ws.notifications || []).filter(n => !n.dismissed && !n.read).length;
    $('#top-notif-count').textContent = unread;
    const badge = $('#nav-notif-badge');
    badge.textContent = unread;
    badge.classList.toggle('hidden', unread === 0);

    const monOn = ws.monitoring?.enabled;
    $('#sidebar-mon-dot').classList.toggle('paused', !monOn);
    $('#sidebar-mon-label').textContent = monOn ? SetuI18n.t('mon_active') : SetuI18n.t('mon_paused');
  }

  // ---------------- 1. MY SETU OVERVIEW ----------------
  async function refreshMySetuLive() {
    const loc = getActiveLoc();
    if (!loc) {
      toast(SetuI18n.getLang() === 'hi' ? 'कृपया पहले Settings में अपना स्थान सहेजें।' : 'Please save a location in Settings first.');
      showView('settings');
      return;
    }
    try {
      const [wxRes, vayuRes] = await Promise.all([
        api('/api/weather', { method: 'POST', body: JSON.stringify({ lat: loc.lat, lon: loc.lon, locationLabel: loc.label }) }),
        api('/api/vayu/analyze', { method: 'POST', body: JSON.stringify({ lat: loc.lat, lon: loc.lon, locationLabel: loc.label }) })
      ]);
      liveWeather = wxRes.weather;
      liveAqi = vayuRes;
      renderMySetu();
      renderWeatherView(wxRes.weather, wxRes.interpretation);
      renderVayuView(vayuRes);
    } catch (e) {
      toast(e.message);
    }
  }

  function renderMySetu() {
    const lang = SetuI18n.getLang();
    const loc = getActiveLoc();

    // Location Card
    if (loc) {
      $('#ms-loc-prov').className = 'prov-pill prov-user';
      $('#ms-loc-prov').textContent = SetuI18n.t('prov_user');
      $('#ms-loc-body').innerHTML = `<p><strong>${esc(loc.label || 'Saved Coordinates')}</strong></p><p class="tiny-note">${Number(loc.lat).toFixed(4)}, ${Number(loc.lon).toFixed(4)}</p>`;
    } else {
      $('#ms-loc-prov').className = 'prov-pill prov-unavail';
      $('#ms-loc-prov').textContent = SetuI18n.t('prov_unavail');
      $('#ms-loc-body').innerHTML = `<div class="cute-empty">${esc(SetuI18n.t('loc_missing'))} <br/><button class="pill-btn soft-mint" style="margin-top:8px;" onclick="App.showView('settings')">Set Location →</button></div>`;
    }

    // Weather Card
    if (liveWeather) {
      $('#ms-wx-prov').className = 'prov-pill prov-retrieved';
      $('#ms-wx-prov').textContent = SetuI18n.t('prov_retrieved');
      const cond = lang === 'hi' ? liveWeather.conditionHi : liveWeather.condition;
      $('#mysetu-sky-caption').textContent = `${liveWeather.temperatureC}°C · ${cond}`;
      $('#mysetu-rain-svg').classList.toggle('hidden', !liveWeather.rainfall.rainedTodayObserved && liveWeather.rainProbNext4h < 40);
      $('#mysetu-last-checked').textContent = `${lang === 'hi' ? 'अंतिम जाँच:' : 'Last checked:'} ${new Date(liveWeather.fetchedAt).toLocaleTimeString()}`;

      $('#ms-wx-body').innerHTML = `
        <p><strong>${liveWeather.temperatureC}°C · ${esc(cond)}</strong></p>
        <p class="tiny-note">${lang === 'hi' ? `आज दर्ज बारिश: ${liveWeather.rainfall.todayObservedMm} mm · कल संभावना: ${liveWeather.rainfall.tomorrowRainProb ?? 0}%` : `Observed rain today: ${liveWeather.rainfall.todayObservedMm} mm · Tomorrow prob: ${liveWeather.rainfall.tomorrowRainProb ?? 0}%`}</p>
      `;
    } else {
      $('#ms-wx-prov').className = 'prov-pill prov-unavail';
      $('#ms-wx-prov').textContent = SetuI18n.t('prov_unavail');
      $('#ms-wx-body').innerHTML = `<div class="cute-empty">${lang === 'hi' ? 'लाइव मौसम अभी लोड नहीं हुआ।' : 'Weather not checked yet.'}</div>`;
    }

    // AQI Card
    if (liveAqi?.aqiData) {
      const a = liveAqi.aqiData;
      $('#ms-aqi-prov').className = 'prov-pill prov-retrieved';
      $('#ms-aqi-prov').textContent = SetuI18n.t('prov_retrieved');
      const cat = lang === 'hi' ? a.category.hi : a.category.en;
      $('#ms-aqi-body').innerHTML = `
        <p><strong>NAQI ${a.indianNaqi ?? a.usAqi ?? '--'} (${esc(cat)})</strong></p>
        <p class="tiny-note">PM2.5: ${a.pollutants.pm25 ?? '--'} µg/m³ · PM10: ${a.pollutants.pm10 ?? '--'} µg/m³</p>
      `;
    } else {
      $('#ms-aqi-prov').className = 'prov-pill prov-unavail';
      $('#ms-aqi-prov').textContent = SetuI18n.t('prov_unavail');
      $('#ms-aqi-body').innerHTML = `<div class="cute-empty">${lang === 'hi' ? 'वायु गुणवत्ता जाँचने के लिए रिफ्रेश करें।' : 'Check VayuSetu to view live AQI.'}</div>`;
    }

    // Farm Card
    const fields = ws.kisanMemory.fields || [];
    const soil = (ws.savedItems || []).find(s => s.type === 'soil');
    if (fields.length || ws.kisanMemory.cropsGrown || soil) {
      $('#ms-farm-prov').className = 'prov-pill prov-user';
      $('#ms-farm-prov').textContent = SetuI18n.t('prov_user');
      $('#ms-farm-body').innerHTML = `
        <p><strong>${fields.length} ${lang === 'hi' ? 'खेत सहेजे गए' : 'Field(s)'}</strong> · ${esc(ws.kisanMemory.cropsGrown || 'No crop set')}</p>
        <p class="tiny-note">${soil ? esc(soil.summary) : (lang === 'hi' ? 'मिट्टी रिपोर्ट अभी अपलोड नहीं है।' : 'No soil report uploaded yet.')}</p>
      `;
    } else {
      $('#ms-farm-prov').className = 'prov-pill prov-unavail';
      $('#ms-farm-prov').textContent = SetuI18n.t('prov_unavail');
      $('#ms-farm-body').innerHTML = `<div class="cute-empty">${lang === 'hi' ? 'खेत जोड़ने के लिए किसानसेतु खोलें।' : 'Map a field or add crops in KisanSetu.'}</div>`;
    }

    // Monitoring Card
    const mon = ws.monitoring;
    $('#mysetu-mon-chip').textContent = mon.enabled ? `🕒 ${SetuI18n.t('mon_active')}` : `⏸ ${SetuI18n.t('mon_paused')}`;
    $('#ms-mon-body').innerHTML = `
      <p class="tiny-note"><b>${lang === 'hi' ? 'स्थिति:' : 'Last Check:'}</b> ${mon.lastCheckAt ? new Date(mon.lastCheckAt).toLocaleString() : 'Never'}</p>
      <p class="tiny-note"><b>${lang === 'hi' ? 'अगली जाँच:' : 'Next Check:'}</b> ${mon.nextCheckAt ? new Date(mon.nextCheckAt).toLocaleString() : 'Not scheduled'}</p>
    `;

    // Recent Conversations & Saved
    const convs = ws.conversations || [];
    const saved = ws.savedItems || [];
    $('#ms-recent-body').innerHTML = `
      <p class="tiny-note"><b>${convs.length}</b> ${lang === 'hi' ? 'बातचीत' : 'conversation(s)'} · <b>${saved.length}</b> ${lang === 'hi' ? 'सहेजे गए आइटम' : 'saved report(s)'} · <b>${ws.memories.length}</b> ${lang === 'hi' ? 'याद रखे तथ्य' : 'memories'}</p>
      ${convs.slice(0, 2).map(c => `<div style="margin-top:6px;"><button class="pill-btn soft-mint" onclick="App.openConversation('${esc(c.id)}')">💬 ${esc(c.title)}</button></div>`).join('')}
    `;
  }

  // Quick Actions
  function quickDidItRain() {
    showView('weather');
    loadWeatherLive();
  }
  function quickTomorrowWeather() {
    showView('chat');
    sendSuggested(SetuI18n.getLang() === 'hi' ? 'मेरे स्थान पर कल मौसम कैसा रहेगा और क्या बारिश होगी?' : 'What is tomorrow\'s weather and rain forecast for my location?');
  }

  // ---------------- 2. VAYUSETU ----------------
  async function loadVayuLive() {
    const loc = getActiveLoc();
    if (!loc) return toast('Save a location in Settings first.');
    $('#btn-vayu-refresh').disabled = true;
    $('#vayu-aqi-metrics').textContent = 'Fetching live Copernicus CAMS AQI...';
    try {
      const res = await api('/api/vayu/analyze', {
        method: 'POST',
        body: JSON.stringify({ lat: loc.lat, lon: loc.lon, locationLabel: loc.label, languageCode: SetuI18n.getLang() })
      });
      liveAqi = res;
      if (res.weather) liveWeather = res.weather;
      renderVayuView(res);
      renderMySetu();
    } catch (e) {
      $('#vayu-aqi-metrics').innerHTML = `<div class="cute-empty">${esc(e.message)}</div>`;
    } finally {
      $('#btn-vayu-refresh').disabled = false;
    }
  }

  function renderVayuView(res) {
    const a = res.aqiData;
    const lang = SetuI18n.getLang();
    $('#vayu-aqi-prov').className = 'prov-pill prov-retrieved';
    $('#vayu-aqi-prov').textContent = esc(a.provider);
    const cat = lang === 'hi' ? a.category.hi : a.category.en;
    $('#vayu-aqi-metrics').innerHTML = `
      <div class="kpi-row-3">
        <div class="kpi-pill"><span>Indian NAQI</span><strong>${a.indianNaqi ?? '--'}</strong><small>${esc(cat)}</small></div>
        <div class="kpi-pill"><span>PM2.5</span><strong>${a.pollutants.pm25 ?? '--'}</strong><small>µg/m³</small></div>
        <div class="kpi-pill"><span>PM10</span><strong>${a.pollutants.pm10 ?? '--'}</strong><small>µg/m³</small></div>
      </div>
      <p class="tiny-note">NO₂: ${a.pollutants.no2 ?? '--'} · Ozone: ${a.pollutants.ozone ?? '--'} · Observed: ${new Date(a.observationTime).toLocaleString()}</p>
    `;

    if (res.guidance) {
      const g = res.guidance;
      $('#vayu-guidance-box').innerHTML = `
        <p><strong>${esc(g.headline)}</strong></p>
        <p class="tiny-note"><b>Outdoor:</b> ${esc(g.outdoorSafety)}</p>
        <p class="tiny-note"><b>Family:</b> ${esc(g.familyProtection)}</p>
        <p class="tiny-note"><b>Indoor:</b> ${esc(g.indoorAirGuidance)}</p>
        <p class="tiny-note"><b>Commute:</b> ${esc(g.cleanerCommuting)}</p>
        <ul>${(g.dailyPlanTips || []).map(t => `<li class="tiny-note">${esc(t)}</li>`).join('')}</ul>
      `;
    } else if (res.aiError) {
      $('#vayu-guidance-box').innerHTML = `<div class="cute-empty">⚠ ${esc(res.aiError)}</div>`;
    }

    if (res.bridge) {
      const b = res.bridge;
      $('#vayu-bridge-box').innerHTML = `
        <p>${esc(b.bridgeSummary)}</p>
        <p class="tiny-note"><b>Weather → Air:</b> ${esc(b.weatherToAirLink)}</p>
        <p class="tiny-note"><b>Farm ↔ Environment:</b> ${esc(b.farmAndEnvironmentLink)}</p>
        <ul>${(b.sharedRecommendations || []).map(x => `<li class="tiny-note">${esc(x)}</li>`).join('')}</ul>
      `;
    } else if (res.aiError) {
      $('#vayu-bridge-box').innerHTML = `<div class="cute-empty">⚠ ${esc(res.aiError)}</div>`;
    }
  }

  // ---------------- 3. KISANSETU SUB-MODULES ----------------
  function ensureKisanMap() {
    if (kMap) return;
    const sat = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { attribution: 'Tiles © Esri', maxZoom: 19 });
    const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OSM', maxZoom: 19 });
    const loc = getActiveLoc();
    kMap = L.map('kisan-map', { center: loc ? [loc.lat, loc.lon] : [22.9734, 78.6569], zoom: loc ? 15 : 5, layers: [sat] });
    L.control.layers({ Satellite: sat, Street: osm }).addTo(kMap);
    kDrawn = new L.FeatureGroup();
    kMap.addLayer(kDrawn);
    kMap.addControl(new L.Control.Draw({
      edit: { featureGroup: kDrawn },
      draw: { polygon: { allowIntersection: false, showArea: true, shapeOptions: { color: '#facc15', weight: 3 } }, rectangle: true, polyline: false, circle: false, circlemarker: false, marker: false }
    }));
    kMap.on(L.Draw.Event.CREATED, e => { kDrawn.clearLayers(); kDrawn.addLayer(e.layer); onPolygonUpdate(e.layer); });
    kMap.on(L.Draw.Event.EDITED, e => e.layers.eachLayer(onPolygonUpdate));
  }

  async function onPolygonUpdate(layer) {
    kActiveGeo = layer.toGeoJSON();
    const sqm = turf.area(kActiveGeo);
    const [lon, lat] = turf.centroid(kActiveGeo).geometry.coordinates;
    kActiveArea = { sqm, acres: sqm / 4046.8564224, hectares: sqm / 10000, centroid: { lat, lon }, locationNote: '' };
    $('#k-area-ac').textContent = kActiveArea.acres.toFixed(2);
    $('#k-area-ha').textContent = kActiveArea.hectares.toFixed(3);
    $('#k-area-sqm').textContent = Math.round(sqm).toLocaleString('en-IN');
    $('#f-ha').value = kActiveArea.hectares.toFixed(3);
    try {
      const g = await api(`/api/geocode?lat=${lat}&lon=${lon}`);
      kActiveArea.locationNote = [g.village, g.district, g.state].filter(Boolean).join(', ');
      $('#k-area-loc').textContent = kActiveArea.locationNote || `${lat.toFixed(4)}, ${lon.toFixed(4)}`;
    } catch {
      $('#k-area-loc').textContent = `${lat.toFixed(4)}, ${lon.toFixed(4)}`;
    }
  }

  async function searchMapLoc() {
    const q = $('#map-search-q').value.trim();
    if (!q) return;
    const res = await api(`/api/geocode/search?q=${encodeURIComponent(q)}`);
    const box = $('#map-search-list');
    box.classList.remove('hidden');
    box.innerHTML = (res.results || []).map(r => `<button type="button" onclick="App.jumpKMap(${r.lat},${r.lon})">${esc(r.displayName)}</button>`).join('');
  }
  function jumpKMap(lat, lon) { ensureKisanMap(); kMap.setView([lat, lon], 16); $('#map-search-list').classList.add('hidden'); }
  function gpsMapLoc() { navigator.geolocation?.getCurrentPosition(p => jumpKMap(p.coords.latitude, p.coords.longitude)); }

  async function saveFieldForm(e) {
    e.preventDefault();
    if (kActiveArea.sqm <= 0) return toast('Draw a field polygon first!');
    await api('/api/fields', {
      method: 'POST',
      body: JSON.stringify({
        name: $('#k-field-name').value.trim(),
        crop: $('#k-field-crop').value,
        areaSqm: kActiveArea.sqm,
        areaAcres: kActiveArea.acres,
        areaHectares: kActiveArea.hectares,
        centroid: kActiveArea.centroid,
        coordinates: kActiveGeo?.geometry?.coordinates || [],
        locationNote: kActiveArea.locationNote
      })
    });
    await refreshWorkspace();
    renderAll();
    toast('Field saved!');
  }

  function renderSavedFields() {
    const fields = ws.kisanMemory.fields || [];
    $('#k-saved-fields').innerHTML = fields.length
      ? fields.map(f => `<div class="list-card"><div><strong>${esc(f.name)}</strong> (${esc(f.crop || '—')})<div class="tiny-note">${Number(f.areaAcres).toFixed(2)} ac · ${Number(f.areaHectares).toFixed(3)} ha · ${esc(f.locationNote || '')}</div></div><button class="pill-btn peach" onclick="App.delField('${esc(f.id)}')">✕</button></div>`).join('')
      : `<div class="cute-empty">No saved fields yet.</div>`;
  }
  async function delField(id) { await api(`/api/fields/${id}`, { method: 'DELETE' }); await refreshWorkspace(); renderAll(); }

  async function uploadSoilFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    $('#k-soil-status').textContent = 'Analyzing Soil Health Card with Gemini...';
    const prev = $('#k-soil-preview');
    prev.classList.remove('hidden');
    let base64Data, mimeType = file.type || 'image/jpeg';
    if (mimeType === 'application/pdf') {
      base64Data = await readDataUrl(file);
      prev.innerHTML = `<iframe src="${base64Data}"></iframe>`;
    } else {
      base64Data = await compressImg(file, 1400);
      mimeType = 'image/jpeg';
      prev.innerHTML = `<img src="${base64Data}" alt="Soil preview"/>`;
    }
    try {
      const res = await api('/api/soil/analyze', {
        method: 'POST',
        body: JSON.stringify({ base64Data, mimeType, fileName: file.name, languageCode: SetuI18n.getLang() })
      });
      const p = res.extracted.parameters || {};
      const mapIds = { ph:'#s-ph', ec:'#s-ec', organicCarbon:'#s-oc', nitrogen:'#s-n', phosphorus:'#s-p', potassium:'#s-k', sulphur:'#s-s', zinc:'#s-zn', iron:'#s-fe', boron:'#s-b' };
      Object.entries(mapIds).forEach(([k, sel]) => { $(sel).value = p[k] ?? ''; });
      $('#k-soil-explain').innerHTML = `<p><b>${esc(res.extracted.plainLanguageSummary)}</b></p>` + (res.extracted.parameterExplanations || []).map(x => `<div>• <b>${esc(x.parameter)}:</b> ${esc(x.meaning)}</div>`).join('');
      $('#k-soil-status').textContent = '✅ Extracted. Verify any blank/ambiguous fields.';
      await refreshWorkspace();
      renderAll();
    } catch (err) {
      $('#k-soil-status').textContent = `❌ ${err.message}`;
    }
  }

  async function saveSoilReview() {
    const parameters = {
      ph: num('#s-ph'), ec: num('#s-ec'), organicCarbon: num('#s-oc'), nitrogen: num('#s-n'),
      phosphorus: num('#s-p'), potassium: num('#s-k'), sulphur: num('#s-s'), zinc: num('#s-zn'), iron: num('#s-fe'), boron: num('#s-b')
    };
    await api('/api/saved', {
      method: 'POST',
      body: JSON.stringify({
        type: 'soil', module: 'kisan', title: 'Verified Soil Report', provenance: 'User-Verified',
        summary: `pH ${parameters.ph ?? 'N/A'}, N ${parameters.nitrogen ?? 'N/A'}, P ${parameters.phosphorus ?? 'N/A'}, K ${parameters.potassium ?? 'N/A'}`,
        data: { parameters }
      })
    });
    await refreshWorkspace();
    renderAll();
    toast('Soil parameters saved!');
  }

  function useSoilInFertilizer() {
    $('#f-n').value = $('#s-n').value;
    $('#f-p').value = $('#s-p').value;
    $('#f-k').value = $('#s-k').value;
    openKisanSub('fert');
  }

  async function runCropAdvice(e) {
    e.preventDefault();
    $('#btn-cr-go').disabled = true;
    $('#cr-output').textContent = 'Analyzing suitability...';
    try {
      const res = await api('/api/crops/recommend', {
        method: 'POST',
        body: JSON.stringify({
          state: $('#cr-state').value, district: $('#cr-dist').value, season: $('#cr-season').value,
          waterAvailability: $('#cr-water').value, soilType: $('#cr-soiltype').value, preferences: $('#cr-pref').value,
          useTinyFishGrounding: $('#cr-tf').checked, languageCode: SetuI18n.getLang()
        })
      });
      const r = res.result;
      $('#cr-output').innerHTML = `<p class="tiny-note"><b>Caveat:</b> ${esc(r.modelCaveat)}</p>` +
        (r.recommendations || []).map(c => `<div class="list-card"><div><strong>${esc(c.cropName)}</strong> (${esc(c.suitabilityLevel)})<div class="tiny-note">${esc(c.reasons.join(' '))}</div><div class="tiny-note"><b>Limitations:</b> ${esc(c.potentialLimitations.join('; '))}</div></div></div>`).join('');
      await refreshWorkspace();
    } catch (err) {
      $('#cr-output').textContent = err.message;
    } finally {
      $('#btn-cr-go').disabled = false;
    }
  }

  async function runFertCalc(e) {
    e.preventDefault();
    $('#btn-f-go').disabled = true;
    try {
      const res = await api('/api/fertilizer/calculate', {
        method: 'POST',
        body: JSON.stringify({
          cropName: $('#f-crop').value, areaHectares: Number($('#f-ha').value),
          soilParams: { nitrogen: num('#f-n'), phosphorus: num('#f-p'), potassium: num('#f-k') },
          fetchOfficialAdvisory: $('#f-tf').checked
        })
      });
      const c = res.calculation;
      if (!c.supported) {
        $('#f-output').innerHTML = `<div class="cute-empty">${esc(c.missingInformation.join(' '))}</div>`;
        return;
      }
      $('#f-output').innerHTML = `
        <div class="kpi-row-3">
          <div class="kpi-pill"><span>Urea</span><strong>${c.quantities.ureaBags50kg} bags</strong><small>${c.quantities.ureaKg} kg</small></div>
          <div class="kpi-pill"><span>DAP</span><strong>${c.quantities.dapBags50kg} bags</strong><small>${c.quantities.dapKg} kg</small></div>
          <div class="kpi-pill"><span>MOP</span><strong>${c.quantities.mopBags50kg} bags</strong><small>${c.quantities.mopKg} kg</small></div>
        </div>
        <p class="tiny-note"><b>Source:</b> ${esc(c.sourceCitation)}</p>
        <ul class="tiny-note">${c.formulas.map(f => `<li>${esc(f)}</li>`).join('')}</ul>
        ${res.officialLinks?.length ? `<div class="tiny-note"><b>TinyFish References:</b> ${res.officialLinks.map(l => `<a href="${esc(l.url)}" target="_blank">${esc(l.title)}</a>`).join(' · ')}</div>` : ''}
      `;
      await refreshWorkspace();
    } catch (err) {
      $('#f-output').textContent = err.message;
    } finally {
      $('#btn-f-go').disabled = false;
    }
  }

  async function uploadDiseasePhoto(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const b64 = await compressImg(file, 1024);
    $('#d-preview').src = b64;
    $('#d-preview').classList.remove('hidden');
    $('#d-output').textContent = 'Inspecting plant symptoms...';
    try {
      const res = await api('/api/disease/analyze', {
        method: 'POST',
        body: JSON.stringify({ base64Data: b64, mimeType: 'image/jpeg', cropHint: $('#d-crop').value, notes: $('#d-notes').value, languageCode: SetuI18n.getLang() })
      });
      const a = res.analysis;
      $('#d-output').innerHTML = `
        <p><strong>${esc(a.likelyCrop)}</strong> · Image Quality: <b>${esc(a.imageQuality)}</b></p>
        <p class="tiny-note">${esc(a.imageQualityFeedback)}</p>
        <p class="tiny-note"><b>Symptoms:</b> ${esc(a.visibleSymptoms.join('; '))}</p>
        <p class="tiny-note"><b>Possible Causes:</b> ${esc(a.possibleCauses.join('; '))}</p>
        <ul>${a.potentialIdentifications.map(p => `<li class="tiny-note"><b>${esc(p.name)}</b> (${esc(p.confidence)}) — ${esc(p.uncertaintyNote)}</li>`).join('')}</ul>
        <p class="tiny-note"><b>Next Steps:</b> ${esc(a.recommendedNextSteps.join('; '))}</p>
        <p class="tiny-note">⚠️ ${esc(a.safetyCaution)}</p>
      `;
      await refreshWorkspace();
    } catch (err) {
      $('#d-output').textContent = err.message;
    }
  }

  // ---------------- 4. WEATHER & "IT RAINED HERE" ----------------
  async function loadWeatherLive() {
    const loc = getActiveLoc();
    if (!loc) return toast('Save a location in Settings first.');
    $('#wx-rain-summary').textContent = 'Retrieving observed & forecast rainfall...';
    try {
      const res = await api('/api/weather', {
        method: 'POST',
        body: JSON.stringify({ lat: loc.lat, lon: loc.lon, locationLabel: loc.label, languageCode: SetuI18n.getLang() })
      });
      liveWeather = res.weather;
      renderWeatherView(res.weather, res.interpretation);
      renderMySetu();
    } catch (e) {
      $('#wx-rain-summary').textContent = e.message;
    }
  }

  function renderWeatherView(w, interp) {
    const lang = SetuI18n.getLang();
    $('#wx-prov').className = 'prov-pill prov-retrieved';
    $('#wx-prov').textContent = esc(w.provider);
    $('#wx-rain-summary').innerHTML = `
      <div class="kpi-row-3">
        <div class="kpi-pill"><span>${lang === 'hi' ? 'आज दर्ज बारिश (Observed)' : 'Observed Today'}</span><strong>${w.rainfall.todayObservedMm} mm</strong></div>
        <div class="kpi-pill"><span>${lang === 'hi' ? 'पिछले 24 घंटे' : 'Last 24h Observed'}</span><strong>${w.rainfall.last24hObservedMm} mm</strong></div>
        <div class="kpi-pill"><span>${lang === 'hi' ? 'कल पूर्वानुमान' : 'Tomorrow Forecast'}</span><strong>${w.rainfall.tomorrowRainProb ?? 0}% (${w.rainfall.tomorrowForecastMm ?? 0}mm)</strong></div>
      </div>
      <p class="tiny-note">Observed at ${new Date(w.observationTime).toLocaleString()} · Temp ${w.temperatureC}°C · Wind ${w.windSpeedKmh} km/h · Humidity ${w.humidityPercent}%</p>
      <p class="tiny-note"><b>Spray Check:</b> ${esc(lang === 'hi' ? w.sprayWindow.headlineHi : w.sprayWindow.headline)}</p>
    `;

    // Rain Chart (Observed vs Forecast)
    const ctx = $('#rain-chart')?.getContext('2d');
    if (ctx && w.daily?.length) {
      if (rainChart) rainChart.destroy();
      rainChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: w.daily.map(d => `${d.date.slice(5)} ${d.isPast ? '(Obs)' : d.isToday ? '(Today)' : '(Fcst)'}`),
          datasets: [{
            label: 'Precipitation (mm)',
            data: w.daily.map(d => d.rainMm),
            backgroundColor: w.daily.map(d => d.isPast || d.isToday ? '#3b82f6' : '#93c5fd'),
            borderRadius: 8
          }]
        },
        options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
      });
    }

    if (interp) {
      $('#wx-ai-box').innerHTML = `
        <p><strong>${esc(interp.rainSummary)}</strong></p>
        <p class="tiny-note"><b>Irrigation:</b> ${esc(interp.irrigationGuidance)}</p>
        <p class="tiny-note"><b>Rain Precautions:</b> ${esc(interp.rainPrecautions)}</p>
        <p class="tiny-note"><b>Heat Stress:</b> ${esc(interp.heatStressAssessment)}</p>
        <p class="tiny-note"><b>Spraying:</b> ${esc(interp.sprayingGuidance)}</p>
      `;
    }
  }

  function askWeatherInChat() {
    showView('chat');
    sendSuggested(SetuI18n.getLang() === 'hi' ? 'क्या आज मेरे स्थान पर बारिश हुई और क्या मुझे सिंचाई करनी चाहिए?' : 'Did it rain here today and should I irrigate my crop?');
  }

  // ---------------- 5. AI CHAT (TOOL ROUTING + STREAMING + MARKDOWN) ----------------
  function renderChatView() {
    renderConversationList();
    const conv = ws.conversations.find(c => c.id === activeConvId) || ws.conversations[0];
    if (!conv) return;
    activeConvId = conv.id;
    $('#chat-active-title').textContent = conv.title;
    const log = $('#chat-stream-log');
    log.innerHTML = '';
    if (!conv.messages.length) {
      log.innerHTML = `<div class="bubble bot">${esc(SetuI18n.t('chat_welcome'))}</div>`;
      return;
    }
    conv.messages.forEach(m => appendChatBubble(m));
  }

  function renderConversationList() {
    const q = ($('#chat-search-input')?.value || '').toLowerCase();
    const list = (ws.conversations || []).filter(c => !q || c.title.toLowerCase().includes(q));
    $('#chat-conv-list').innerHTML = list.map(c => `
      <div class="conv-item ${c.id === activeConvId ? 'active' : ''}" onclick="App.openConversation('${esc(c.id)}')">
        <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">💬 ${esc(c.title)}</span>
        <button onclick="event.stopPropagation(); App.deleteConv('${esc(c.id)}')" title="Delete">✕</button>
      </div>
    `).join('');
  }

  async function startNewChat(focus = true) {
    const res = await api('/api/conversations', { method: 'POST', body: JSON.stringify({ title: SetuI18n.getLang() === 'hi' ? 'नई बातचीत' : 'New Conversation' }) });
    await refreshWorkspace();
    activeConvId = res.conversation.id;
    renderChatView();
    if (focus) $('#chat-input-box').focus();
  }

  function openConversation(id) {
    activeConvId = id;
    showView('chat');
  }

  async function renameActiveChat() {
    const title = prompt('Rename conversation:', $('#chat-active-title').textContent);
    if (!title) return;
    await api(`/api/conversations/${activeConvId}`, { method: 'PUT', body: JSON.stringify({ title }) });
    await refreshWorkspace();
    renderChatView();
  }

  async function deleteConv(id) {
    await api(`/api/conversations/${id}`, { method: 'DELETE' });
    await refreshWorkspace();
    activeConvId = ws.conversations[0]?.id || null;
    if (!activeConvId) await startNewChat(false);
    renderChatView();
    renderMySetu();
  }

  function renderMarkdown(md) {
    let html = esc(md || '');
    // Links [label](url)
    html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1 ↗</a>');
    // Bold **text**
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    // Bullet lines
    const lines = html.split('\n');
    let out = '', inUl = false;
    for (const line of lines) {
      if (/^\s*[-*]\s+/.test(line)) {
        if (!inUl) { out += '<ul>'; inUl = true; }
        out += `<li>${line.replace(/^\s*[-*]\s+/, '')}</li>`;
      } else {
        if (inUl) { out += '</ul>'; inUl = false; }
        if (/^###\s+/.test(line)) out += `<h4>${line.replace(/^###\s+/, '')}</h4>`;
        else if (/^##\s+/.test(line)) out += `<h4>${line.replace(/^##\s+/, '')}</h4>`;
        else out += `${line}<br/>`;
      }
    }
    if (inUl) out += '</ul>';
    return out;
  }

  function appendChatBubble(msg) {
    const log = $('#chat-stream-log');
    const div = document.createElement('div');
    div.className = `bubble ${msg.role === 'user' ? 'user' : 'bot'}`;
    if (msg.role === 'user') {
      div.textContent = msg.text;
    } else {
      div.innerHTML = `<div class="md-body">${renderMarkdown(msg.text)}</div>`;
      if (msg.citations?.length) {
        div.innerHTML += `<div class="cite-chips">${msg.citations.map(c => `<a class="cite-chip" href="${esc(c.url)}" target="_blank" rel="noopener">${esc(c.title)} ↗</a>`).join('')}</div>`;
      }
      if (msg.toolsUsed?.length) {
        div.innerHTML += `<div class="tiny-note">Tools: ${esc(msg.toolsUsed.join(' · '))}</div>`;
      }
      const act = document.createElement('div');
      act.className = 'bubble-actions';
      act.innerHTML = `
        <button type="button" onclick="App.copyText(this)">📋 ${SetuI18n.t('btn_copy')}</button>
        <button type="button" onclick="App.speakBubble(this)">🔊 ${SetuI18n.t('btn_listen')}</button>
        <button type="button" onclick="App.saveAnswerToReports(this)">📌 ${SetuI18n.t('btn_save_answer')}</button>
      `;
      div.appendChild(act);
    }
    log.appendChild(div);
    log.scrollTop = log.scrollHeight;
    return div;
  }

  function copyText(btn) {
    const txt = btn.closest('.bubble').querySelector('.md-body')?.innerText || '';
    navigator.clipboard?.writeText(txt);
    toast('Copied!');
  }

  function speakBubble(btn) {
    const txt = btn.closest('.bubble').querySelector('.md-body')?.innerText || '';
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(txt);
    u.lang = SetuI18n.getLang() === 'hi' ? 'hi-IN' : 'en-IN';
    window.speechSynthesis.speak(u);
  }

  async function saveAnswerToReports(btn) {
    const txt = btn.closest('.bubble').querySelector('.md-body')?.innerText || '';
    await api('/api/saved', {
      method: 'POST',
      body: JSON.stringify({ type: 'chat', module: 'shared', title: txt.slice(0, 50), provenance: 'Saved AI Response', summary: txt.slice(0, 180), data: { text: txt } })
    });
    await refreshWorkspace();
    renderAll();
    toast('Answer saved!');
  }

  function sendSuggested(q) {
    $('#chat-input-box').value = q;
    submitChat(new Event('submit'));
  }

  async function attachChatFile(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    const b64 = await compressImg(f, 1024);
    chatAttachment = { base64: b64, mimeType: 'image/jpeg', name: f.name };
    $('#chat-attach-thumb').src = b64;
    $('#chat-attach-name').textContent = f.name;
    $('#chat-attach-bar').classList.remove('hidden');
  }

  function clearChatAttachment() { chatAttachment = null; $('#chat-attach-bar').classList.add('hidden'); }

  function toggleChatVoice() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return toast('Speech input unavailable in this browser.');
    if (voiceActive && voiceRec) { voiceRec.stop(); return; }
    voiceRec = new SR();
    voiceRec.lang = SetuI18n.getLang() === 'hi' ? 'hi-IN' : 'en-IN';
    voiceRec.onstart = () => { voiceActive = true; $('#chat-voice-btn').textContent = '⏹ Listening...'; };
    voiceRec.onend = () => { voiceActive = false; $('#chat-voice-btn').innerHTML = `🎙️ ${SetuI18n.t('btn_voice')}`; };
    voiceRec.onresult = (e) => { $('#chat-input-box').value = e.results?.[0]?.[0]?.transcript || ''; };
    voiceRec.start();
  }

  function stopChatStream() { chatAbortController?.abort(); }

  async function submitChat(e) {
    e.preventDefault();
    const message = $('#chat-input-box').value.trim();
    if (!message && !chatAttachment) return;
    $('#chat-input-box').value = '';
    const log = $('#chat-stream-log');
    if (log.querySelector('.bubble.bot')?.textContent === SetuI18n.t('chat_welcome')) log.innerHTML = '';

    appendChatBubble({ role: 'user', text: message || '[Image attached]' });
    const botBubble = appendChatBubble({ role: 'assistant', text: '...' });
    const mdContainer = botBubble.querySelector('.md-body');

    $('#chat-tool-status').classList.remove('hidden');
    $('#chat-stop-btn').classList.remove('hidden');
    $('#chat-send-btn').disabled = true;
    chatAbortController = new AbortController();

    let accumulated = '';
    try {
      const resp = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: chatAbortController.signal,
        body: JSON.stringify({
          conversationId: activeConvId,
          message,
          imageBase64: chatAttachment?.base64 || null,
          mimeType: chatAttachment?.mimeType || null,
          languageCode: SetuI18n.getLang()
        })
      });
      clearChatAttachment();
      const reader = resp.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const blocks = buf.split('\n\n');
        buf = blocks.pop() || '';
        for (const b of blocks) {
          let evt = 'message', dataStr = '';
          for (const l of b.split('\n')) {
            if (l.startsWith('event:')) evt = l.slice(6).trim();
            if (l.startsWith('data:')) dataStr += l.slice(5).trim();
          }
          if (!dataStr) continue;
          const d = JSON.parse(dataStr);
          if (evt === 'tool_status') {
            $('#chat-tool-label').textContent = d.label;
          } else if (evt === 'chunk') {
            accumulated += d.text;
            mdContainer.innerHTML = renderMarkdown(accumulated);
            log.scrollTop = log.scrollHeight;
          } else if (evt === 'done') {
            await refreshWorkspace();
            renderAll();
            if (d.rememberedFact) toast(`Remembered: ${d.rememberedFact}`);
          } else if (evt === 'error') {
            mdContainer.textContent = `❌ ${d.error}`;
          }
        }
      }
    } catch (err) {
      if (err.name !== 'AbortError') mdContainer.textContent = `Error: ${err.message}`;
    } finally {
      $('#chat-tool-status').classList.add('hidden');
      $('#chat-stop-btn').classList.add('hidden');
      $('#chat-send-btn').disabled = false;
    }
  }

  // ---------------- 6. RESEARCH & SCHEMES ----------------
  async function runResearchQuery(e) {
    e.preventDefault();
    $('#btn-res-go').disabled = true;
    $('#res-out').textContent = SetuI18n.getLang() === 'hi' ? 'विश्वसनीय स्रोतों से जानकारी खोजी जा रही है...' : 'Researching public portals with TinyFish...';
    try {
      const d = await api('/api/research', { method: 'POST', body: JSON.stringify({ query: $('#res-q').value, languageCode: SetuI18n.getLang() }) });
      $('#res-out').innerHTML = `
        <p>${esc(d.executiveSummary)}</p>
        <ul>${(d.keyFindings || []).map(k => `<li class="tiny-note">${esc(k)}</li>`).join('')}</ul>
        <div class="cite-chips">${(d.citations || []).map(c => `<a class="cite-chip" href="${esc(c.url)}" target="_blank">${esc(c.title)} ↗</a>`).join('')}</div>
      `;
      await refreshWorkspace();
      renderAll();
    } catch (err) {
      $('#res-out').textContent = err.message;
    } finally {
      $('#btn-res-go').disabled = false;
    }
  }

  async function runSchemeFinder(e) {
    e.preventDefault();
    $('#btn-sch-go').disabled = true;
    $('#sch-out').textContent = 'Querying .gov.in portals via TinyFish...';
    try {
      const d = await api('/api/schemes/find', {
        method: 'POST',
        body: JSON.stringify({ state: $('#sch-st').value, crop: $('#sch-cr').value, schemeType: $('#sch-ty').value, languageCode: SetuI18n.getLang() })
      });
      $('#sch-out').innerHTML = (d.schemes || []).map(s => `
        <div class="list-card"><div><strong>${esc(s.schemeName)}</strong> <span class="prov-pill prov-retrieved">${esc(s.verificationStatus)}</span>
        <div class="tiny-note"><b>Eligibility:</b> ${esc(s.eligibility)} · <b>Benefits:</b> ${esc(s.benefits)}</div>
        <a href="${esc(s.sourceUrl)}" target="_blank" style="font-size:0.78rem;">Official Source ↗</a></div></div>
      `).join('') || `<div class="cute-empty">${esc(d.overviewNote)}</div>`;
      await refreshWorkspace();
      renderAll();
    } catch (err) {
      $('#sch-out').textContent = err.message;
    } finally {
      $('#btn-sch-go').disabled = false;
    }
  }

  // ---------------- 7, 8, 9. NOTIFICATIONS, SAVED, MONITORING ----------------
  function renderNotifications() {
    const list = ws.notifications || [];
    $('#notif-list').innerHTML = list.length
      ? list.map(n => `
        <div class="list-card ${n.read ? '' : 'unread'}">
          <div>
            <strong>${esc(n.title)}</strong>
            <div class="tiny-note">${esc(n.message)}</div>
            <div class="tiny-note">${new Date(n.createdAt).toLocaleString()}</div>
          </div>
          <div style="display:flex;gap:6px;">
            <button class="pill-btn soft-mint" onclick="App.showView('${esc(n.linkView || 'mysetu')}')">Open</button>
            <button class="pill-btn peach" onclick="App.dismissNotif('${esc(n.id)}')">Dismiss</button>
          </div>
        </div>
      `).join('')
      : `<div class="cute-empty">${SetuI18n.getLang() === 'hi' ? 'अभी कोई नया अलर्ट नहीं है।' : 'No notifications right now. Alerts appear automatically when monitoring detects rain, AQI changes, or advisories.'}</div>`;
  }

  async function markAllNotifications(dismiss) {
    await api('/api/notifications/read', { method: 'POST', body: JSON.stringify({ id: 'all', dismiss }) });
    await refreshWorkspace();
    renderAll();
  }
  async function dismissNotif(id) {
    await api('/api/notifications/read', { method: 'POST', body: JSON.stringify({ id, dismiss: true }) });
    await refreshWorkspace();
    renderAll();
  }
  function requestBrowserPush() {
    if (!('Notification' in window)) return toast('Browser notifications unsupported.');
    Notification.requestPermission().then(p => toast(`Notification permission: ${p}`));
  }

  function renderSavedItems() {
    const items = ws.savedItems || [];
    $('#saved-list').innerHTML = items.length
      ? items.map(s => `
        <div class="list-card">
          <div>
            <span class="prov-pill prov-ai">${esc(s.type)}</span> <strong>${esc(s.title)}</strong>
            <div class="tiny-note">${esc(s.summary)} · ${new Date(s.createdAt).toLocaleString()}</div>
          </div>
          <div style="display:flex;gap:6px;">
            <button class="pill-btn soft-mint" onclick="App.viewSaved('${esc(s.id)}')">View</button>
            <button class="pill-btn peach" onclick="App.deleteSaved('${esc(s.id)}')">✕</button>
          </div>
        </div>
      `).join('')
      : `<div class="cute-empty">No saved reports or answers yet.</div>`;
  }

  function viewSaved(id) {
    const item = ws.savedItems.find(x => x.id === id);
    if (!item) return;
    $('#modal-title').textContent = item.title;
    $('#modal-body').innerHTML = `<p>${esc(item.summary)}</p><pre style="white-space:pre-wrap;font-size:0.78rem;background:#faf8f2;padding:12px;border-radius:12px;">${esc(JSON.stringify(item.data, null, 2))}</pre>`;
    $('#detail-modal').classList.remove('hidden');
  }
  function closeModal() { $('#detail-modal').classList.add('hidden'); }
  async function deleteSaved(id) { await api(`/api/saved/${id}`, { method: 'DELETE' }); await refreshWorkspace(); renderAll(); }

  function renderMonitoring() {
    const m = ws.monitoring;
    $('#mon-enabled').checked = m.enabled;
    $('#mon-freq').value = String(m.frequencyMinutes || 360);
    $('#mon-air').checked = m.topics.air;
    $('#mon-wx').checked = m.topics.weather;
    $('#mon-farm').checked = m.topics.farming;
    $('#mon-res').checked = m.topics.research;
    $('#mon-topic-q').value = m.researchTopicQuery || '';

    $('#mon-status-summary').innerHTML = `
      <div><b>Scheduler:</b> ${esc(health.schedulerMode || 'Active')}</div>
      <div><b>Last check:</b> ${m.lastCheckAt ? new Date(m.lastCheckAt).toLocaleString() : 'Never'} (${esc(m.lastStatus)})</div>
      <div><b>Next scheduled check:</b> ${m.nextCheckAt ? new Date(m.nextCheckAt).toLocaleString() : 'Paused'}</div>
      ${m.lastError ? `<div style="color:#b91c1c;"><b>Last note:</b> ${esc(m.lastError)}</div>` : ''}
    `;
    $('#mon-history-list').innerHTML = (m.history || []).map(h => `
      <div class="list-card"><div><strong>${new Date(h.checkedAt).toLocaleString()}</strong> (${esc(h.status)})<div class="tiny-note">${esc(h.summary)} · Alerts: ${h.alertsCreated}</div></div></div>
    `).join('') || `<div class="cute-empty">No monitoring checks run yet. Click "Run Check Now".</div>`;
  }

  async function saveMonitoringSettings(e) {
    e.preventDefault();
    await api('/api/monitoring/config', {
      method: 'PUT',
      body: JSON.stringify({
        enabled: $('#mon-enabled').checked,
        frequencyMinutes: Number($('#mon-freq').value),
        topics: { air: $('#mon-air').checked, weather: $('#mon-wx').checked, farming: $('#mon-farm').checked, research: $('#mon-res').checked },
        researchTopicQuery: $('#mon-topic-q').value
      })
    });
    await refreshWorkspace();
    renderAll();
    toast('Monitoring preferences saved!');
  }

  async function triggerManualMonitoring() {
    $('#btn-mon-run').disabled = true;
    try {
      const res = await api('/api/monitoring/run', { method: 'POST' });
      await refreshWorkspace();
      renderAll();
      toast(`Monitoring check finished · ${res.alertsCreated || 0} new alert(s)`);
    } catch (e) {
      toast(e.message);
    } finally {
      $('#btn-mon-run').disabled = false;
    }
  }

  // ---------------- 10. SETTINGS & PERSISTENT MEMORY ----------------
  function renderSettingsForm() {
    const s = ws.shared, v = ws.vayuMemory, k = ws.kisanMemory;
    $('#set-name').value = s.name || '';
    $('#set-loc-label').value = s.location?.label || '';
    $('#set-lat').value = s.location?.lat ?? '';
    $('#set-lon').value = s.location?.lon ?? '';
    $('#set-units').value = s.units || 'metric';
    $('#set-vayu-house').value = v.householdContext || '';
    $('#set-vayu-sched').value = v.dailySchedule || '';
    $('#set-kisan-crops').value = k.cropsGrown || '';
    $('#set-kisan-season').value = k.farmingSeason || '';
    $('#set-kisan-soil').value = k.soilType || '';
    $('#set-kisan-irr').value = k.irrigationType || '';

    $('#mem-list').innerHTML = (ws.memories || []).length
      ? ws.memories.map(m => `
        <div class="list-card">
          <div><span class="prov-pill prov-user">${esc(m.scope)}</span> ${esc(m.text)}<div class="tiny-note">From: ${esc(m.source)}</div></div>
          <div style="display:flex;gap:6px;">
            <button class="pill-btn soft-mint" onclick="App.editMem('${esc(m.id)}','${esc(m.text)}')">Edit</button>
            <button class="pill-btn peach" onclick="App.delMem('${esc(m.id)}')">✕</button>
          </div>
        </div>
      `).join('')
      : `<div class="cute-empty">No custom remembered facts yet. Tell AI Chat "Remember that..." or add one above!</div>`;
  }

  async function searchSettingsLoc() {
    const q = $('#set-loc-q').value.trim();
    if (!q) return;
    const res = await api(`/api/geocode/search?q=${encodeURIComponent(q)}`);
    const box = $('#set-loc-results');
    box.classList.remove('hidden');
    box.innerHTML = (res.results || []).map(r => `<button type="button" onclick="App.pickSettingsLoc(${r.lat},${r.lon},'${esc(r.displayName)}')">${esc(r.displayName)}</button>`).join('');
  }
  function pickSettingsLoc(lat, lon, label) {
    $('#set-lat').value = lat.toFixed(4);
    $('#set-lon').value = lon.toFixed(4);
    $('#set-loc-label').value = label.split(',').slice(0, 2).join(',').trim();
    $('#set-loc-results').classList.add('hidden');
  }
  function gpsSettingsLoc() {
    navigator.geolocation?.getCurrentPosition(p => {
      $('#set-lat').value = p.coords.latitude.toFixed(4);
      $('#set-lon').value = p.coords.longitude.toFixed(4);
      if (!$('#set-loc-label').value) $('#set-loc-label').value = 'My GPS Location';
    });
  }

  async function saveSettingsForm(e) {
    e.preventDefault();
    const lat = num('#set-lat'), lon = num('#set-lon');
    const location = Number.isFinite(lat) && Number.isFinite(lon)
      ? { label: $('#set-loc-label').value.trim() || `${lat}, ${lon}`, lat, lon }
      : null;

    await api('/api/settings', {
      method: 'PUT',
      body: JSON.stringify({
        shared: { name: $('#set-name').value, units: $('#set-units').value, location },
        vayuMemory: { householdContext: $('#set-vayu-house').value, dailySchedule: $('#set-vayu-sched').value },
        kisanMemory: { cropsGrown: $('#set-kisan-crops').value, farmingSeason: $('#set-kisan-season').value, soilType: $('#set-kisan-soil').value, irrigationType: $('#set-kisan-irr').value }
      })
    });
    await refreshWorkspace();
    renderAll();
    toast('Settings & memory saved!');
    if (location) refreshMySetuLive();
  }

  async function addManualMemory(e) {
    e.preventDefault();
    await api('/api/memories', { method: 'POST', body: JSON.stringify({ scope: $('#mem-scope').value, text: $('#mem-text').value }) });
    $('#mem-text').value = '';
    await refreshWorkspace();
    renderAll();
  }
  async function editMem(id, oldText) {
    const text = prompt('Edit remembered fact:', oldText);
    if (!text) return;
    await api(`/api/memories/${id}`, { method: 'PUT', body: JSON.stringify({ text }) });
    await refreshWorkspace();
    renderAll();
  }
  async function delMem(id) { await api(`/api/memories/${id}`, { method: 'DELETE' }); await refreshWorkspace(); renderAll(); }
  async function clearAllAccountData() {
    if (!confirm('Clear all saved locations, fields, chats, and memories?')) return;
    await api('/api/settings/account', { method: 'DELETE' });
    liveWeather = null; liveAqi = null;
    await refreshWorkspace();
    await startNewChat(false);
    renderAll();
    toast('All workspace memory cleared.');
  }

  // Helpers
  function num(sel) {
    const v = $(sel)?.value;
    return v !== '' && v != null && Number.isFinite(Number(v)) ? Number(v) : null;
  }
  function readDataUrl(f) {
    return new Promise((res, rej) => { const r = new FileReader(); r.onload = e => res(e.target.result); r.onerror = rej; r.readAsDataURL(f); });
  }
  function compressImg(file, maxDim = 1024) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      readDataUrl(file).then(src => {
        img.onload = () => {
          let { width, height } = img;
          if (width > maxDim || height > maxDim) {
            if (width >= height) { height = Math.round((height * maxDim) / width); width = maxDim; }
            else { width = Math.round((width * maxDim) / height); height = maxDim; }
          }
          const c = document.createElement('canvas'); c.width = width; c.height = height;
          c.getContext('2d').drawImage(img, 0, 0, width, height);
          resolve(c.toDataURL('image/jpeg', 0.85));
        };
        img.onerror = reject; img.src = src;
      }).catch(reject);
    });
  }

  window.addEventListener('DOMContentLoaded', init);

  return {
    showView, switchModule, openKisanSub, toggleSidebar, changeLanguage,
    refreshMySetuLive, quickDidItRain, quickTomorrowWeather,
    loadVayuLive, searchMapLoc, jumpKMap, gpsMapLoc, saveFieldForm, delField,
    uploadSoilFile, saveSoilReview, useSoilInFertilizer, runCropAdvice, runFertCalc, uploadDiseasePhoto,
    loadWeatherLive, askWeatherInChat,
    startNewChat, openConversation, renameActiveChat, deleteConv, renderConversationList,
    sendSuggested, attachChatFile, clearChatAttachment, toggleChatVoice, stopChatStream, submitChat,
    copyText, speakBubble, saveAnswerToReports,
    runResearchQuery, runSchemeFinder,
    markAllNotifications, dismissNotif, requestBrowserPush,
    viewSaved, closeModal, deleteSaved,
    saveMonitoringSettings, triggerManualMonitoring,
    searchSettingsLoc, pickSettingsLoc, gpsSettingsLoc, saveSettingsForm,
    addManualMemory, editMem, delMem, clearAllAccountData
  };
})();
