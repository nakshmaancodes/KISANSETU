/**
 * Real Backend Scheduled Monitoring Service
 * - Runs periodic checks via Node background scheduler (when running on Node/Render)
 * - Also exposes runMonitoringCycle() for /api/monitoring/run and Vercel Cron (/api/cron/monitor)
 * - Never fabricates notifications; creates deduplicated alerts strictly from real Weather, AQI & TinyFish checks.
 */

import {
  listWorkspaceIds,
  getWorkspaceState,
  addNotification,
  recordMonitoringRun
} from './storageService.js';
import { fetchRealWeather, fetchRealAirQuality } from './weatherService.js';
import { tinyfishSearch } from './tinyfishService.js';

let schedulerHandle = null;

export async function runMonitoringCycle(userId = 'default', { force = false } = {}) {
  const ws = getWorkspaceState(userId);
  const mon = ws.monitoring;

  if (!mon.enabled && !force) {
    return { skipped: true, reason: 'Monitoring is disabled for this workspace.' };
  }

  const loc = ws.shared.location || ws.shared.farmLocation || ws.kisanMemory.fields?.[0]?.centroid;
  if (!loc || !Number.isFinite(Number(loc.lat)) || !Number.isFinite(Number(loc.lon))) {
    const updated = recordMonitoringRun(userId, {
      status: 'skipped_no_location',
      error: 'No saved location set. Save a location in Settings or Smart Field Mapping to activate checks.',
      summary: 'Skipped: no saved location.'
    });
    return { monitoring: updated, alertsCreated: 0 };
  }

  const lang = ws.shared.preferredLanguage || 'en';
  const locLabel = loc.label || `${Number(loc.lat).toFixed(2)}, ${Number(loc.lon).toFixed(2)}`;
  const todayKey = new Date().toISOString().slice(0, 10);
  let alertsCreated = 0;
  const summaryParts = [];
  const snapshotPatch = {};

  try {
    // 1. Weather & Farming Monitoring
    if (mon.topics.weather || mon.topics.farming) {
      const w = await fetchRealWeather(loc.lat, loc.lon);
      summaryParts.push(`Temp ${w.temperatureC}°C, Wind ${w.windSpeedKmh} km/h, Today Rain ${w.rainfall.todayObservedMm}mm`);

      if (w.rainfall.rainedTodayObserved || w.rainProbNext4h >= 55) {
        const eventKey = `rain_${todayKey}`;
        const n = addNotification(userId, {
          eventKey,
          type: 'rain',
          module: w.rainfall.rainedTodayObserved ? 'weather' : 'kisan',
          title: lang === 'hi'
            ? `🌧️ ${locLabel} में बारिश की जानकारी`
            : `🌧️ Rain detected / expected in ${locLabel}`,
          message: lang === 'hi'
            ? `आज दर्ज बारिश: ${w.rainfall.todayObservedMm} mm · अगले 4 घंटे में संभावना: ${w.rainProbNext4h}% (स्रोत: ${w.provider})`
            : `Observed today: ${w.rainfall.todayObservedMm} mm · Next 4h rain probability: ${w.rainProbNext4h}% (Source: ${w.provider})`,
          linkView: 'weather'
        });
        if (n) alertsCreated++;
        snapshotPatch.lastRainAlertKey = eventKey;
      }

      if (mon.topics.farming && (w.windSpeedKmh > 15 || w.temperatureC >= 38 || w.temperatureC <= 4)) {
        const eventKey = `farm_wx_${todayKey}_${w.windSpeedKmh > 15 ? 'wind' : 'temp'}`;
        const n = addNotification(userId, {
          eventKey,
          type: 'farming',
          module: 'kisan',
          title: lang === 'hi'
            ? `🌾 खेती मौसम चेतावनी (${locLabel})`
            : `🌾 Farming weather advisory (${locLabel})`,
          message: w.warnings.join(' ') || w.sprayWindow.headline,
          linkView: 'kisansetu'
        });
        if (n) alertsCreated++;
      }
    }

    // 2. Air Quality (VayuSetu) Monitoring
    if (mon.topics.air) {
      const aqi = await fetchRealAirQuality(loc.lat, loc.lon);
      const val = aqi.indianNaqi ?? aqi.usAqi;
      summaryParts.push(`NAQI ${val ?? 'N/A'} (${aqi.category.en})`);

      const prevAqi = mon.snapshot?.lastUsAqi;
      const worsened = prevAqi != null && val != null && val - prevAqi >= 40;
      if ((val != null && val >= 200) || worsened) {
        const eventKey = `aqi_${todayKey}_${aqi.category.level}`;
        const n = addNotification(userId, {
          eventKey,
          type: 'aqi',
          module: 'vayu',
          title: lang === 'hi'
            ? `🌫️ आपके स्थान पर आज हवा की गुणवत्ता ${aqi.category.hi} है (AQI ${val})`
            : `🌫️ Air quality is ${aqi.category.en} in ${locLabel} (AQI ${val})`,
          message: lang === 'hi'
            ? `PM2.5: ${aqi.pollutants.pm25 ?? 'N/A'} µg/m³ · बाहर जाने से पहले VayuSetu सलाह देखें।`
            : `PM2.5: ${aqi.pollutants.pm25 ?? 'N/A'} µg/m³ · PM10: ${aqi.pollutants.pm10 ?? 'N/A'} µg/m³. View VayuSetu guidance.`,
          linkView: 'vayusetu'
        });
        if (n) alertsCreated++;
      }
      if (val != null) snapshotPatch.lastUsAqi = val;
    }

    // 3. TinyFish Research Topic Monitoring (optional if enabled + configured)
    if (mon.topics.research && mon.researchTopicQuery && (process.env.TINYFISH_API_KEY || '').trim()) {
      try {
        const sr = await tinyfishSearch(`${mon.researchTopicQuery} ${locLabel}`, { location: 'IN' });
        const top = sr.items?.[0];
        if (top && top.url !== mon.snapshot?.lastResearchHash) {
          const n = addNotification(userId, {
            eventKey: `res_${todayKey}_${top.url.slice(0, 40)}`,
            type: 'research',
            module: 'research',
            title: lang === 'hi'
              ? `🔎 नया सरकारी/कृषि अपडेट मिला`
              : `🔎 New advisory update found for "${mon.researchTopicQuery}"`,
            message: `${top.title} — ${top.snippet?.slice(0, 140) || ''}`,
            sourceUrl: top.url,
            linkView: 'research'
          });
          if (n) alertsCreated++;
          snapshotPatch.lastResearchHash = top.url;
        }
        summaryParts.push(`Research checked (${sr.items.length} results)`);
      } catch (err) {
        summaryParts.push(`Research error: ${err.message}`);
      }
    }

    const updated = recordMonitoringRun(userId, {
      status: 'ok',
      summary: summaryParts.join(' · ') || 'Checked',
      snapshotPatch,
      alertsCreated
    });
    return { monitoring: updated, alertsCreated };
  } catch (err) {
    const updated = recordMonitoringRun(userId, {
      status: 'error',
      error: err.message,
      summary: `Check failed: ${err.message}`
    });
    return { monitoring: updated, alertsCreated: 0, error: err.message };
  }
}

export async function runAllScheduledMonitoring() {
  const ids = listWorkspaceIds();
  const results = [];
  const now = Date.now();
  for (const id of ids) {
    const ws = getWorkspaceState(id);
    if (!ws.monitoring.enabled) continue;
    const nextMs = ws.monitoring.nextCheckAt ? Date.parse(ws.monitoring.nextCheckAt) : 0;
    if (!nextMs || now >= nextMs) {
      results.push({ userId: id, ...(await runMonitoringCycle(id)) });
    }
  }
  return results;
}

export function startBackgroundScheduler() {
  if (schedulerHandle || process.env.VERCEL === '1') return;
  // Poll every 10 minutes for due workspaces
  schedulerHandle = setInterval(() => {
    runAllScheduledMonitoring().catch((err) => {
      console.error('[SETU Scheduler] Background check error:', err.message);
    });
  }, 10 * 60 * 1000);
  schedulerHandle.unref?.();
}
