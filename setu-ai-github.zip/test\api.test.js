import assert from 'node:assert/strict';

const BASE = 'http://localhost:3000';
const TEST_USER = 'setu_e2e_' + Date.now();
const headers = { 'Content-Type': 'application/json', 'x-setu-user': TEST_USER };

async function req(path, opts = {}) {
  const res = await fetch(`${BASE}${path}`, { ...opts, headers: { ...headers, ...(opts.headers || {}) } });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data };
}

async function readChatSse(body) {
  const res = await fetch(`${BASE}/api/chat/stream`, {
    method: 'POST',
    headers,
    body: JSON.stringify(body)
  });
  assert.equal(res.status, 200);
  const text = await res.text();
  const events = [];
  for (const block of text.split('\n\n')) {
    let evt = '', dataStr = '';
    for (const l of block.split('\n')) {
      if (l.startsWith('event:')) evt = l.slice(6).trim();
      if (l.startsWith('data:')) dataStr += l.slice(5).trim();
    }
    if (evt && dataStr) events.push({ evt, data: JSON.parse(dataStr) });
  }
  return events;
}

async function run() {
  console.log('1. Checking /api/health & /api/meta...');
  const h = await req('/api/health');
  assert.equal(h.status, 200);
  assert.equal(h.data.product, 'SETU AI');
  assert.equal(h.data.geminiConfigured, true);
  assert.equal(h.data.tinyfishConfigured, true);

  console.log('2. Saving Persistent Location, Hindi Preference & Memories...');
  const setRes = await req('/api/settings', {
    method: 'PUT',
    body: JSON.stringify({
      shared: {
        name: 'Aarav',
        preferredLanguage: 'hi',
        location: { label: 'Karnal, Haryana', lat: 29.6857, lon: 76.9905 }
      },
      vayuMemory: { householdContext: 'Elderly parents at home', dailySchedule: 'Morning walk 6:30 AM' },
      kisanMemory: { cropsGrown: 'Wheat', farmingSeason: 'Rabi', soilType: 'Alluvial' }
    })
  });
  assert.equal(setRes.status, 200);
  assert.equal(setRes.data.workspace.shared.preferredLanguage, 'hi');

  const memAdd = await req('/api/memories', {
    method: 'POST',
    body: JSON.stringify({ scope: 'kisan', text: 'Wheat sown on Nov 10' })
  });
  assert.equal(memAdd.status, 200);

  console.log('3. Checking Persistence across workspace reload...');
  const wsCheck = await req('/api/workspace');
  assert.equal(wsCheck.data.workspace.shared.location.label, 'Karnal, Haryana');
  assert.equal(wsCheck.data.workspace.shared.preferredLanguage, 'hi');
  assert.ok(wsCheck.data.workspace.memories.length >= 1);

  console.log('4. Testing Observed vs Forecast Rainfall (/api/weather)...');
  const wx = await req('/api/weather', { method: 'POST', body: JSON.stringify({}) });
  assert.equal(wx.status, 200);
  assert.ok(wx.data.weather.rainfall.todayObservedMm !== undefined);
  assert.ok(wx.data.weather.rainfall.tomorrowRainProb !== undefined);
  assert.ok(wx.data.interpretation.rainSummary.length > 5);

  console.log('5. Testing VayuSetu Live AQI + Environmental Bridge (/api/vayu/analyze)...');
  const vayu = await req('/api/vayu/analyze', { method: 'POST', body: JSON.stringify({}) });
  assert.equal(vayu.status, 200);
  assert.ok(vayu.data.aqiData.indianNaqi !== null || vayu.data.aqiData.usAqi !== null);
  assert.ok(vayu.data.guidance.headline.length > 5);
  assert.ok(vayu.data.bridge.bridgeSummary.length > 5);

  console.log('6. Testing KisanSetu Fields & Fertilizer Math...');
  const fld = await req('/api/fields', {
    method: 'POST',
    body: JSON.stringify({ name: 'Plot A', crop: 'Wheat', areaSqm: 10000, areaAcres: 2.471, areaHectares: 1.0, centroid: { lat: 29.6857, lon: 76.9905 } })
  });
  assert.equal(fld.status, 200);

  const fert = await req('/api/fertilizer/calculate', {
    method: 'POST',
    body: JSON.stringify({ cropName: 'Wheat', areaHectares: 1.0, fetchOfficialAdvisory: false })
  });
  assert.equal(fert.status, 200);
  assert.equal(fert.data.calculation.supported, true);

  console.log('7. Testing Real Tool-Routing Streaming Chat in HINDI...');
  const convRes = await req('/api/conversations', { method: 'POST', body: JSON.stringify({ title: 'Hindi Weather Test' }) });
  const convId = convRes.data.conversation.id;
  const sseEvents = await readChatSse({
    conversationId: convId,
    message: 'क्या आज मेरे स्थान पर बारिश हुई और क्या हवा दौड़ने के लिए सुरक्षित है?',
    languageCode: 'hi'
  });
  const doneEvt = sseEvents.find(e => e.evt === 'done');
  assert.ok(doneEvt, 'Chat SSE stream must emit done event');
  assert.equal(doneEvt.data.responseLanguage, 'hi');
  assert.ok(doneEvt.data.toolsUsed.includes('Open-Meteo Weather'));
  assert.ok(doneEvt.data.toolsUsed.includes('Open-Meteo AQI'));
  const hindiText = sseEvents.filter(e => e.evt === 'chunk').map(e => e.data.text).join('');
  assert.ok(/[\u0900-\u097F]/.test(hindiText), 'Hindi reply must contain Devanagari Hindi text');

  console.log('8. Testing TinyFish Research & Govt Schemes...');
  const resOut = await req('/api/research', {
    method: 'POST',
    body: JSON.stringify({ query: 'ICAR wheat advisory', languageCode: 'en' })
  });
  assert.equal(resOut.status, 200);
  assert.ok(Array.isArray(resOut.data.citations));

  console.log('9. Testing Real Scheduled Monitoring & Deduplicated Notifications...');
  const monRun1 = await req('/api/monitoring/run', { method: 'POST' });
  assert.equal(monRun1.status, 200);
  assert.equal(monRun1.data.monitoring.lastStatus, 'ok');

  const cronRes = await req('/api/cron/monitor');
  assert.equal(cronRes.status, 200);
  assert.equal(cronRes.data.ok, true);

  console.log('10. Cleaning up test workspace...');
  await req('/api/settings/account', { method: 'DELETE' });
  console.log('ALL_SETU_AI_TESTS_PASSED');
}

run().catch((err) => {
  console.error('TEST_FAILED:', err);
  process.exit(1);
});
