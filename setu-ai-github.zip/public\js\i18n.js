/* SETU AI — Complete Bilingual Dictionary (English & हिन्दी) */
window.SetuI18n = (function () {
  const dict = {
    en: {
      brand_sub: 'Environmental & Agricultural Intelligence',
      nav_mysetu: 'My Setu — Overview',
      nav_vayusetu: 'VayuSetu — Air & Smog',
      nav_kisansetu: 'KisanSetu — Farming',
      nav_weather: 'Weather & Rain',
      nav_chat: 'AI Chat',
      nav_research: 'Research & Schemes',
      nav_notifications: 'Notifications',
      nav_saved: 'Saved',
      nav_monitoring: 'Monitoring',
      nav_settings: 'Settings',
      mod_kisan: 'KisanSetu',
      mod_vayu: 'VayuSetu',
      btn_new_chat: '+ New Chat',
      btn_run_check: 'Run Check Now',
      btn_save: 'Save',
      btn_send: 'Send',
      btn_stop: 'Stop',
      btn_copy: 'Copy',
      btn_save_answer: 'Save Answer',
      btn_regen: 'Regenerate',
      btn_listen: 'Listen',
      btn_voice: 'Voice',
      btn_attach: 'Photo / File',
      btn_use_gps: 'Use My GPS',
      btn_search: 'Search',
      btn_landing: 'Landing Home',
      hero_greeting: 'Hello! How can I help you today?',
      mysetu_title: 'My Setu — Connected Overview',
      mysetu_sub: 'Live location, weather, air quality, farming alerts, automatic monitoring, and your saved memory in one warm home.',
      quick_actions_title: 'Quick Actions',
      qa_rain: 'Did It Rain Here?',
      qa_tomorrow: "Check Tomorrow's Weather",
      qa_aqi: 'Check Air Quality',
      qa_ask: 'Ask Setu AI',
      qa_research: 'Research an Advisory',
      qa_soil: 'Analyze My Soil',
      qa_fields: 'View My Fields',
      qa_crops: 'Crop Advice',
      qa_alerts: 'View Alerts',
      qa_saved: 'Saved Information',
      loc_current: 'Active Saved Location',
      loc_missing: 'No location saved yet. Search a city, use GPS, or enter manually.',
      mon_active: 'Auto-Monitoring Active',
      mon_paused: 'Monitoring Paused',
      prov_retrieved: 'Real Retrieved',
      prov_user: 'User-Provided',
      prov_ai: 'AI Insight',
      prov_unavail: 'Unavailable',
      vayu_title: 'VayuSetu — Air Quality & Family Protection',
      vayu_sub: 'Live PM2.5, PM10 & Indian NAQI with household protection, indoor air guidance, cleaner commuting, and Environmental Impact Bridge.',
      kisan_title: 'KisanSetu — Precision Farm Intelligence',
      kisan_sub: 'Field mapping, Soil Health Card OCR, crop suitability, deterministic fertilizer math, and crop disease vision.',
      ktab_map: 'Field Mapping',
      ktab_soil: 'Soil Report',
      ktab_crop: 'Crop Advice',
      ktab_fert: 'Fertilizer Math',
      ktab_disease: 'Disease Scan',
      weather_title: 'It Rained Here? — Real Weather & Rain Check',
      weather_sub: 'Distinguishes real observed past/today rainfall from forecast rain for your saved location and farm.',
      chat_welcome: 'Hello! How can I help you today?',
      chat_placeholder: 'Ask about rain today, AQI for running, wheat fertilizer, or latest govt schemes...',
      research_title: 'Research & Government Schemes (TinyFish)',
      research_sub: 'Live retrieval from public agricultural & environmental portals with verified citations only.',
      notif_title: 'Notifications Centre',
      notif_sub: 'Real alerts triggered from live weather, AQI changes, farming checks, and TinyFish monitoring.',
      saved_title: 'Saved Reports, Plans & Answers',
      saved_sub: 'Persistent records stored on the backend—view, print as PDF, or remove anytime.',
      mon_title: 'Automatic Background Monitoring',
      mon_sub: 'Scheduled server checks for air quality, rainfall, farming risks, and official advisories.',
      set_title: 'Settings, Location & Persistent Memory',
      set_sub: 'Manage your shared profile, VayuSetu household context, KisanSetu farm context, and remembered facts.'
    },
    hi: {
      brand_sub: 'पर्यावरण एवं कृषि बुद्धिमत्ता',
      nav_mysetu: 'माई सेतु — मुख्य पृष्ठ',
      nav_vayusetu: 'वायुसेतु — हवा और स्मॉग',
      nav_kisansetu: 'किसानसेतु — खेती व फसल',
      nav_weather: 'मौसम और बारिश',
      nav_chat: 'AI चैट सहायक',
      nav_research: 'शोध और सरकारी योजनाएँ',
      nav_notifications: 'सूचनाएँ और अलर्ट',
      nav_saved: 'सहेजी गई जानकारी',
      nav_monitoring: 'स्वचालित निगरानी',
      nav_settings: 'सेटिंग्स और मेमोरी',
      mod_kisan: 'किसानसेतु',
      mod_vayu: 'वायुसेतु',
      btn_new_chat: '+ नई बातचीत',
      btn_run_check: 'अभी जाँच चलाएँ',
      btn_save: 'सहेजें',
      btn_send: 'भेजें',
      btn_stop: 'रोकें',
      btn_copy: 'कॉपी करें',
      btn_save_answer: 'उत्तर सहेजें',
      btn_regen: 'पुनः लिखें',
      btn_listen: 'सुनें',
      btn_voice: 'बोलकर पूछें',
      btn_attach: 'फ़ोटो / फ़ाइल',
      btn_use_gps: 'मेरी GPS लोकेशन',
      btn_search: 'खोजें',
      btn_landing: 'होम पेज',
      hero_greeting: 'नमस्ते! आज मैं आपकी कैसे मदद कर सकता हूँ?',
      mysetu_title: 'माई सेतु — एकीकृत डैशबोर्ड',
      mysetu_sub: 'आपका सहेजा गया स्थान, ताज़ा मौसम, हवा की गुणवत्ता (AQI), खेती अलर्ट और स्वचालित निगरानी एक ही जगह।',
      quick_actions_title: 'त्वरित कार्य',
      qa_rain: 'आज बारिश हुई है या नहीं, जाँचें',
      qa_tomorrow: 'कल का मौसम देखें',
      qa_aqi: 'हवा की गुणवत्ता (AQI) जाँचें',
      qa_ask: 'सेतु AI से पूछें',
      qa_research: 'सरकारी सलाह खोजें',
      qa_soil: 'मिट्टी रिपोर्ट जाँचें',
      qa_fields: 'मेरे खेत देखें',
      qa_crops: 'फसल सलाह',
      qa_alerts: 'अलर्ट देखें',
      qa_saved: 'सहेजी गई जानकारी',
      loc_current: 'सहेजा गया स्थान',
      loc_missing: 'अभी कोई स्थान सहेजा नहीं गया है। शहर खोजें, GPS उपयोग करें या मैनुअल लिखें।',
      mon_active: 'स्वचालित निगरानी चालू',
      mon_paused: 'निगरानी रुकी हुई',
      prov_retrieved: 'वास्तविक डेटा',
      prov_user: 'उपयोगकर्ता द्वारा',
      prov_ai: 'AI विश्लेषण',
      prov_unavail: 'उपलब्ध नहीं',
      vayu_title: 'वायुसेतु — हवा की गुणवत्ता और परिवार सुरक्षा',
      vayu_sub: 'ताज़ा PM2.5, PM10 और AQI के साथ घर की हवा, सुरक्षित आवागमन और पर्यावरणीय सेतु सलाह।',
      kisan_title: 'किसानसेतु — सटीक कृषि बुद्धिमत्ता',
      kisan_sub: 'खेत का नक्शा, मृदा स्वास्थ्य कार्ड, फसल उपयुक्तता, सटीक खाद गणना और पौधे के रोग की जाँच।',
      ktab_map: 'खेत का नक्शा',
      ktab_soil: 'मिट्टी रिपोर्ट',
      ktab_crop: 'फसल सलाह',
      ktab_fert: 'खाद गणना',
      ktab_disease: 'रोग पहचान',
      weather_title: 'क्या यहाँ बारिश हुई? — मौसम और वर्षा जाँच',
      weather_sub: 'अपने खेत व स्थान के लिए वास्तविक दर्ज बारिश और आने वाले पूर्वानुमान में स्पष्ट अंतर देखें।',
      chat_welcome: 'नमस्ते! आज मैं आपकी कैसे मदद कर सकता हूँ?',
      chat_placeholder: 'आज बारिश, हवा की गुणवत्ता, गेहूँ की खाद या सरकारी योजनाओं के बारे में पूछें...',
      research_title: 'शोध और सरकारी योजनाएँ (TinyFish)',
      research_sub: 'विश्वसनीय स्रोतों से जानकारी खोजी जा रही है — केवल वास्तविक और प्रमाणित लिंक के साथ।',
      notif_title: 'सूचना केंद्र',
      notif_sub: 'ताज़ा मौसम, हवा की गुणवत्ता में बदलाव, खेती और TinyFish निगरानी से प्राप्त वास्तविक अलर्ट।',
      saved_title: 'सहेजी गई रिपोर्ट, योजनाएँ और उत्तर',
      saved_sub: 'बैकएंड में सुरक्षित जानकारी — कभी भी देखें, PDF प्रिंट करें या हटाएँ।',
      mon_title: 'स्वचालित पृष्ठभूमि निगरानी',
      mon_sub: 'हवा, बारिश, खेती के जोखिम और सरकारी सलाह की नियमित सर्वर-स्तरीय जाँच।',
      set_title: 'सेटिंग्स, स्थान और स्थायी मेमोरी',
      set_sub: 'अपना प्रोफ़ाइल, स्थान, वायुसेतु परिवार संदर्भ, किसानसेतु खेत विवरण और याद रखे गए तथ्य संपादित करें।'
    }
  };

  let currentLang = 'en';

  function setLang(code) {
    currentLang = code === 'hi' ? 'hi' : 'en';
    document.documentElement.lang = currentLang;
    applyTranslations();
  }

  function getLang() {
    return currentLang;
  }

  function t(key) {
    return dict[currentLang]?.[key] || dict.en[key] || key;
  }

  function applyTranslations() {
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const k = el.getAttribute('data-i18n');
      if (k) el.textContent = t(k);
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
      const k = el.getAttribute('data-i18n-placeholder');
      if (k) el.setAttribute('placeholder', t(k));
    });
  }

  return { setLang, getLang, t, applyTranslations };
})();
