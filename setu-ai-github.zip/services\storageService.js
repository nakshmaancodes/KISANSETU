import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const LOCAL_DATA_DIR = path.join(__dirname, '..', 'data');
const LOCAL_DB_PATH = path.join(LOCAL_DATA_DIR, 'db.json');
const TMP_DB_PATH = '/tmp/setu_ai_db.json';

function resolveDbPath() {
  if (process.env.VERCEL === '1') return TMP_DB_PATH;
  return LOCAL_DB_PATH;
}

const DEFAULT_WORKSPACE = () => ({
  shared: {
    name: '',
    preferredLanguage: 'en',
    units: 'metric',
    location: null, // { label, city, district, state, lat, lon, updatedAt }
    farmLocation: null,
    updatedAt: null
  },
  vayuMemory: {
    householdContext: '',
    dailySchedule: '',
    airPreferences: '',
    savedPlans: []
  },
  kisanMemory: {
    soilType: '',
    cropsGrown: '',
    farmingSeason: '',
    irrigationType: '',
    preferences: '',
    fields: []
  },
  memories: [], // { id, scope: 'shared'|'kisan'|'vayu', text, source, updatedAt }
  conversations: [], // { id, title, moduleContext, updatedAt, messages: [] }
  savedItems: [], // { id, type, module, title, provenance, summary, data, createdAt }
  notifications: [], // { id, eventKey, type, module, title, message, sourceUrl, linkView, read, dismissed, createdAt }
  monitoring: {
    enabled: true,
    frequencyMinutes: 360,
    lastCheckAt: null,
    nextCheckAt: null,
    lastStatus: 'never_run',
    lastError: null,
    topics: {
      air: true,
      weather: true,
      farming: true,
      research: false
    },
    researchTopicQuery: '',
    snapshot: {
      lastUsAqi: null,
      lastRainAlertKey: null,
      lastTempAlertKey: null,
      lastResearchHash: null
    },
    history: []
  }
});

function readDb() {
  const p = resolveDbPath();
  try {
    if (!fs.existsSync(p)) return { workspaces: {} };
    const raw = fs.readFileSync(p, 'utf8');
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : { workspaces: {} };
  } catch {
    return { workspaces: {} };
  }
}

function writeDb(db) {
  const p = resolveDbPath();
  try {
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, JSON.stringify(db, null, 2), 'utf8');
  } catch {
    // Fallback to /tmp if local directory is read-only
    fs.writeFileSync(TMP_DB_PATH, JSON.stringify(db, null, 2), 'utf8');
  }
}

function normalizeUserId(userId = 'default') {
  return String(userId || 'default').replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 64) || 'default';
}

function ensureWs(db, userId = 'default') {
  const key = normalizeUserId(userId);
  if (!db.workspaces) db.workspaces = {};
  if (!db.workspaces[key]) {
    db.workspaces[key] = DEFAULT_WORKSPACE();
  } else {
    const def = DEFAULT_WORKSPACE();
    db.workspaces[key] = {
      ...def,
      ...db.workspaces[key],
      shared: { ...def.shared, ...(db.workspaces[key].shared || {}) },
      vayuMemory: { ...def.vayuMemory, ...(db.workspaces[key].vayuMemory || {}) },
      kisanMemory: { ...def.kisanMemory, ...(db.workspaces[key].kisanMemory || {}) },
      monitoring: {
        ...def.monitoring,
        ...(db.workspaces[key].monitoring || {}),
        topics: { ...def.monitoring.topics, ...(db.workspaces[key].monitoring?.topics || {}) },
        snapshot: { ...def.monitoring.snapshot, ...(db.workspaces[key].monitoring?.snapshot || {}) }
      }
    };
  }
  return { key, ws: db.workspaces[key] };
}

export function listWorkspaceIds() {
  const db = readDb();
  const keys = Object.keys(db.workspaces || {});
  return keys.length ? keys : ['default'];
}

export function getWorkspaceState(userId) {
  const db = readDb();
  return ensureWs(db, userId).ws;
}

export function clearWorkspaceData(userId) {
  const db = readDb();
  const key = normalizeUserId(userId);
  db.workspaces[key] = DEFAULT_WORKSPACE();
  writeDb(db);
  return db.workspaces[key];
}

// -------- SHARED CONTEXT & LOCATION --------
export function updateSharedSettings(userId, patch) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  if (patch.name !== undefined) ws.shared.name = String(patch.name).trim();
  if (patch.preferredLanguage !== undefined) ws.shared.preferredLanguage = String(patch.preferredLanguage).trim() || 'en';
  if (patch.units !== undefined) ws.shared.units = String(patch.units).trim() || 'metric';
  if (patch.location !== undefined) {
    ws.shared.location = patch.location ? { ...patch.location, updatedAt: new Date().toISOString() } : null;
  }
  if (patch.farmLocation !== undefined) {
    ws.shared.farmLocation = patch.farmLocation ? { ...patch.farmLocation, updatedAt: new Date().toISOString() } : null;
  }
  ws.shared.updatedAt = new Date().toISOString();
  writeDb(db);
  return ws.shared;
}

export function updateVayuMemory(userId, patch) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  ws.vayuMemory = {
    ...ws.vayuMemory,
    householdContext: String(patch.householdContext ?? ws.vayuMemory.householdContext ?? '').trim(),
    dailySchedule: String(patch.dailySchedule ?? ws.vayuMemory.dailySchedule ?? '').trim(),
    airPreferences: String(patch.airPreferences ?? ws.vayuMemory.airPreferences ?? '').trim()
  };
  writeDb(db);
  return ws.vayuMemory;
}

export function updateKisanMemory(userId, patch) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  ws.kisanMemory = {
    ...ws.kisanMemory,
    soilType: String(patch.soilType ?? ws.kisanMemory.soilType ?? '').trim(),
    cropsGrown: String(patch.cropsGrown ?? ws.kisanMemory.cropsGrown ?? '').trim(),
    farmingSeason: String(patch.farmingSeason ?? ws.kisanMemory.farmingSeason ?? '').trim(),
    irrigationType: String(patch.irrigationType ?? ws.kisanMemory.irrigationType ?? '').trim(),
    preferences: String(patch.preferences ?? ws.kisanMemory.preferences ?? '').trim()
  };
  writeDb(db);
  return ws.kisanMemory;
}

// -------- USER-EDITABLE MEMORIES --------
export function addMemory(userId, { scope = 'shared', text, source = 'User / Chat' }) {
  const clean = String(text || '').trim();
  if (!clean) return null;
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  const exists = ws.memories.find(m => m.text.toLowerCase() === clean.toLowerCase());
  if (exists) return exists;
  const item = {
    id: `mem_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    scope,
    text: clean,
    source,
    updatedAt: new Date().toISOString()
  };
  ws.memories.unshift(item);
  ws.memories = ws.memories.slice(0, 60);
  writeDb(db);
  return item;
}

export function editMemory(userId, memId, text) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  const item = ws.memories.find(m => m.id === memId);
  if (!item) return null;
  item.text = String(text || '').trim();
  item.updatedAt = new Date().toISOString();
  writeDb(db);
  return item;
}

export function deleteMemory(userId, memId) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  const before = ws.memories.length;
  ws.memories = ws.memories.filter(m => m.id !== memId);
  writeDb(db);
  return ws.memories.length < before;
}

// -------- FIELDS --------
export function listFields(userId) {
  return getWorkspaceState(userId).kisanMemory.fields;
}

export function saveField(userId, field) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  const id = field.id || `fld_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const record = {
    id,
    name: String(field.name || 'Unnamed Field').trim(),
    crop: String(field.crop || '').trim(),
    areaSqm: Number(field.areaSqm) || 0,
    areaAcres: Number(field.areaAcres) || 0,
    areaHectares: Number(field.areaHectares) || 0,
    centroid: field.centroid || null,
    coordinates: field.coordinates || [],
    locationNote: String(field.locationNote || '').trim(),
    updatedAt: new Date().toISOString()
  };
  const idx = ws.kisanMemory.fields.findIndex(f => f.id === id);
  if (idx >= 0) ws.kisanMemory.fields[idx] = record;
  else ws.kisanMemory.fields.unshift(record);
  if (!ws.shared.farmLocation && record.centroid) {
    ws.shared.farmLocation = {
      label: record.locationNote || record.name,
      lat: record.centroid.lat,
      lon: record.centroid.lon,
      updatedAt: new Date().toISOString()
    };
  }
  writeDb(db);
  return record;
}

export function deleteField(userId, fieldId) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  const before = ws.kisanMemory.fields.length;
  ws.kisanMemory.fields = ws.kisanMemory.fields.filter(f => f.id !== fieldId);
  writeDb(db);
  return ws.kisanMemory.fields.length < before;
}

// -------- SAVED ITEMS / REPORTS --------
export function listSavedItems(userId, typeFilter = null) {
  const items = getWorkspaceState(userId).savedItems;
  return typeFilter ? items.filter(h => h.type === typeFilter) : items;
}

export function addSavedItem(userId, item) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  const entry = {
    id: `rep_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    type: String(item.type || 'general'),
    module: String(item.module || 'shared'),
    title: String(item.title || 'Saved Analysis'),
    provenance: String(item.provenance || 'AI Interpretation'),
    summary: String(item.summary || ''),
    data: item.data || {},
    createdAt: new Date().toISOString()
  };
  ws.savedItems.unshift(entry);
  ws.savedItems = ws.savedItems.slice(0, 120);
  writeDb(db);
  return entry;
}

export function deleteSavedItem(userId, itemId) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  const before = ws.savedItems.length;
  ws.savedItems = ws.savedItems.filter(h => h.id !== itemId);
  writeDb(db);
  return ws.savedItems.length < before;
}

// -------- CONVERSATIONS (MULTI-CHAT PERSISTENT MEMORY) --------
export function listConversations(userId) {
  return getWorkspaceState(userId).conversations;
}

export function createConversation(userId, { title = 'New Conversation', moduleContext = 'general' } = {}) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  const conv = {
    id: `conv_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    title: String(title).trim() || 'New Conversation',
    moduleContext,
    updatedAt: new Date().toISOString(),
    messages: []
  };
  ws.conversations.unshift(conv);
  ws.conversations = ws.conversations.slice(0, 50);
  writeDb(db);
  return conv;
}

export function renameConversation(userId, convId, title) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  const conv = ws.conversations.find(c => c.id === convId);
  if (!conv) return null;
  conv.title = String(title || '').trim() || conv.title;
  conv.updatedAt = new Date().toISOString();
  writeDb(db);
  return conv;
}

export function deleteConversation(userId, convId) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  const before = ws.conversations.length;
  ws.conversations = ws.conversations.filter(c => c.id !== convId);
  writeDb(db);
  return ws.conversations.length < before;
}

export function appendToConversation(userId, convId, userMsgObj, assistantMsgObj, moduleContext = null) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  let conv = ws.conversations.find(c => c.id === convId);
  if (!conv) {
    conv = {
      id: convId || `conv_${Date.now()}`,
      title: String(userMsgObj.text || 'Chat').slice(0, 46) || 'New Conversation',
      moduleContext: moduleContext || 'general',
      updatedAt: new Date().toISOString(),
      messages: []
    };
    ws.conversations.unshift(conv);
  }
  if (conv.messages.length === 0 && userMsgObj.text) {
    conv.title = String(userMsgObj.text).slice(0, 48);
  }
  if (moduleContext) conv.moduleContext = moduleContext;
  conv.messages.push(userMsgObj, assistantMsgObj);
  conv.messages = conv.messages.slice(-60);
  conv.updatedAt = new Date().toISOString();
  writeDb(db);
  return conv;
}

// -------- NOTIFICATIONS (DEDUPLICATED) --------
export function listNotifications(userId) {
  return getWorkspaceState(userId).notifications.filter(n => !n.dismissed);
}

export function addNotification(userId, notif) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  if (notif.eventKey) {
    const duplicate = ws.notifications.find(
      n => n.eventKey === notif.eventKey && !n.dismissed && Date.now() - new Date(n.createdAt).getTime() < 6 * 3600 * 1000
    );
    if (duplicate) return null;
  }
  const entry = {
    id: `not_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    eventKey: notif.eventKey || null,
    type: notif.type || 'info',
    module: notif.module || 'shared',
    title: String(notif.title || 'Update'),
    message: String(notif.message || ''),
    sourceUrl: notif.sourceUrl || null,
    linkView: notif.linkView || 'mysetu',
    read: false,
    dismissed: false,
    createdAt: new Date().toISOString()
  };
  ws.notifications.unshift(entry);
  ws.notifications = ws.notifications.slice(0, 80);
  writeDb(db);
  return entry;
}

export function markNotificationRead(userId, notifId, dismissed = false) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  if (notifId === 'all') {
    ws.notifications.forEach(n => {
      n.read = true;
      if (dismissed) n.dismissed = true;
    });
  } else {
    const n = ws.notifications.find(x => x.id === notifId);
    if (n) {
      n.read = true;
      if (dismissed) n.dismissed = true;
    }
  }
  writeDb(db);
  return ws.notifications.filter(n => !n.dismissed);
}

// -------- MONITORING --------
export function updateMonitoringConfig(userId, patch) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  if (patch.enabled !== undefined) ws.monitoring.enabled = Boolean(patch.enabled);
  if (patch.frequencyMinutes !== undefined) ws.monitoring.frequencyMinutes = Math.max(15, Number(patch.frequencyMinutes) || 360);
  if (patch.topics) ws.monitoring.topics = { ...ws.monitoring.topics, ...patch.topics };
  if (patch.researchTopicQuery !== undefined) ws.monitoring.researchTopicQuery = String(patch.researchTopicQuery).trim();
  if (ws.monitoring.enabled && !ws.monitoring.nextCheckAt) {
    ws.monitoring.nextCheckAt = new Date(Date.now() + ws.monitoring.frequencyMinutes * 60000).toISOString();
  }
  writeDb(db);
  return ws.monitoring;
}

export function recordMonitoringRun(userId, { status, error = null, summary = '', snapshotPatch = {}, alertsCreated = 0 }) {
  const db = readDb();
  const { ws } = ensureWs(db, userId);
  const now = new Date();
  ws.monitoring.lastCheckAt = now.toISOString();
  ws.monitoring.nextCheckAt = ws.monitoring.enabled
    ? new Date(now.getTime() + ws.monitoring.frequencyMinutes * 60000).toISOString()
    : null;
  ws.monitoring.lastStatus = status;
  ws.monitoring.lastError = error;
  ws.monitoring.snapshot = { ...ws.monitoring.snapshot, ...snapshotPatch };
  ws.monitoring.history.unshift({
    id: `mon_${Date.now()}`,
    checkedAt: now.toISOString(),
    status,
    summary,
    error,
    alertsCreated
  });
  ws.monitoring.history = ws.monitoring.history.slice(0, 30);
  writeDb(db);
  return ws.monitoring;
}
